KAW'S ATS Playground Companion 1.7.1

Windows script installer package. Extract the ZIP, then double-click INSTALL.bat.
Requires Node.js 22 or newer, Python 3 and Microsoft C++ Build Tools for the ATS telemetry module. Keep your compatible SCS telemetry plugin installed in ATS.
This package does not contain a standalone Setup.exe or bundled Node runtime. It preserves existing driver configuration and data in its installation folder.
Natural voices are provided by KAW's shared service; drivers do not install the local voice engine.
To ride with friends: open the Convoy page and use "Can my convoy see me?" / "Join a convoy".
See companion/RELEASE-NOTES-v1.7.1.md and the in-app Help and Privacy pages.
