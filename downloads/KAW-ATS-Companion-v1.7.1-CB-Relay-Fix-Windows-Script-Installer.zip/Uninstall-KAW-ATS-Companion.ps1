[CmdletBinding(SupportsShouldProcess)]
param(
  [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'KAW-ATS-Companion'),
  [switch]$RemoveDriverData
)
$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $InstallRoot 'companion.pid'
if (Test-Path -LiteralPath $pidFile) {
  $companionPid = [int](Get-Content -LiteralPath $pidFile -Raw)
  $entryPath = Join-Path $InstallRoot 'src\index.js'
  $runningProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $companionPid" -ErrorAction SilentlyContinue
  if ($runningProcess -and $runningProcess.CommandLine -and $runningProcess.CommandLine.IndexOf($entryPath, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
    Stop-Process -Id $companionPid -Force -ErrorAction SilentlyContinue
  }
  Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
}
foreach ($link in @(
  (Join-Path ([Environment]::GetFolderPath('Startup')) 'KAW ATS Companion.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Desktop')) "KAW'S ATS Companion.lnk"),
  (Join-Path ([Environment]::GetFolderPath('Desktop')) "KAW'S Radio.url")
)) { if (Test-Path -LiteralPath $link) { Remove-Item -LiteralPath $link -Force } }
if ($RemoveDriverData) {
  if (Test-Path -LiteralPath $InstallRoot) { Remove-Item -LiteralPath $InstallRoot -Recurse -Force }
  Write-Host 'Companion and driver data removed.'
} else {
  Write-Host "Background startup removed. Driver configuration and trip data remain in $InstallRoot."
}


