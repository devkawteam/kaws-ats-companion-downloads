[CmdletBinding()]
param(
  [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'KAW-ATS-Companion'),
  [string]$DriverName = '',
  [string]$PairingCode = '',
  [switch]$EnableLan,
  [switch]$NoAutoStart,
  [switch]$NoDesktopShortcuts,
  [switch]$NonInteractive
)
$ErrorActionPreference = 'Stop'
$Version = '1.7.1'
$Source = Join-Path $PSScriptRoot 'companion'

function Fail($Message) { Write-Host "`nERROR: $Message" -ForegroundColor Red; exit 1 }
function Ask($Prompt, $Default = '') {
  if ($NonInteractive) { return $Default }
  $answer = Read-Host $Prompt
  if ([string]::IsNullOrWhiteSpace($answer)) { return $Default }
  return $answer.Trim()
}
Write-Host "KAW'S ATS PLAYGROUND COMPANION $Version" -ForegroundColor Cyan
Write-Host 'Driver & Convoy Edition Installer'
if (!(Test-Path -LiteralPath (Join-Path $Source 'package.json'))) { Fail "The companion payload is missing. Extract the complete release ZIP before installing." }

$resolvedRoot = [IO.Path]::GetFullPath($InstallRoot)
if ($resolvedRoot -eq [IO.Path]::GetPathRoot($resolvedRoot)) { Fail 'The installation folder cannot be a drive root.' }

$existingPort = 4280
$existingConfigPath = Join-Path $resolvedRoot 'config.json'
if (Test-Path -LiteralPath $existingConfigPath) {
  try {
    $existingConfig = Get-Content -LiteralPath $existingConfigPath -Raw | ConvertFrom-Json
    if ([int]$existingConfig.dashboardPort -gt 0) { $existingPort = [int]$existingConfig.dashboardPort }
  } catch {}
}
$candidatePids = @()
$portOwnerPids = @()
$existingPidFile = Join-Path $resolvedRoot 'companion.pid'
if (Test-Path -LiteralPath $existingPidFile) {
  try { $candidatePids += [int](Get-Content -LiteralPath $existingPidFile -Raw) } catch {}
}
try { $portOwnerPids = @(Get-NetTCPConnection -LocalPort $existingPort -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess) } catch {}
$candidatePids += $portOwnerPids
$entryPath = Join-Path $resolvedRoot 'src\index.js'
foreach ($candidatePid in @($candidatePids | Sort-Object -Unique)) {
  $candidateProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $candidatePid" -ErrorAction SilentlyContinue
  $matchesCompanionPath = $candidateProcess -and $candidateProcess.CommandLine -and $candidateProcess.CommandLine.IndexOf($entryPath, [StringComparison]::OrdinalIgnoreCase) -ge 0
  $isNodePortOwner = $candidateProcess -and $candidateProcess.Name -ieq 'node.exe' -and $portOwnerPids -contains $candidatePid
  if ($matchesCompanionPath -or $isNodePortOwner) {
    Write-Host "Stopping previous Companion process $candidatePid..." -ForegroundColor DarkGray
    $nativeProcess = Get-Process -Id $candidatePid -ErrorAction SilentlyContinue
    if ($nativeProcess) {
      $nativeProcess | Stop-Process -Force -ErrorAction SilentlyContinue
      try { $nativeProcess.WaitForExit(10000) | Out-Null } catch {}
    }
    if (Get-Process -Id $candidatePid -ErrorAction SilentlyContinue) {
      Fail "The previous Companion process $candidatePid did not stop. Restart Windows and run the installer again."
    }
  } elseif ($portOwnerPids -contains $candidatePid) {
    Fail "Port $existingPort is being used by $($candidateProcess.Name) (PID $candidatePid). Close that program or select another dashboard port."
  }
}

$node = Get-Command node.exe -ErrorAction SilentlyContinue
if (!$node) { Fail 'Node.js 22 LTS or newer is required. Install it from https://nodejs.org and run this installer again.' }
$nodeMajor = [int]((& $node.Source --version).TrimStart('v').Split('.')[0])
if ($nodeMajor -lt 22) { Fail "Node.js 22 or newer is required. Detected version $(& $node.Source --version)." }
$npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
if (!$npm) { Fail 'npm was not found with Node.js.' }

if (!$DriverName) { $DriverName = Ask 'Driver/call-sign name' $env:USERNAME }
if (!$PairingCode) { $PairingCode = Ask 'Convoy pairing code (optional; press Enter to skip)' '' }
if (!$NonInteractive -and !$PSBoundParameters.ContainsKey('EnableLan')) {
  $EnableLan = (Ask 'Allow tablets/phones on your private Wi-Fi? (Y/N)' 'N') -match '^(y|yes)$'
}

New-Item -ItemType Directory -Force -Path $resolvedRoot | Out-Null
$preserve = @('config.json', 'data', 'companion.log', 'companion-error.log')
foreach ($item in Get-ChildItem -LiteralPath $resolvedRoot -Force -ErrorAction SilentlyContinue) {
  if ($preserve -notcontains $item.Name -and $item.Name -ne 'node_modules') { Remove-Item -LiteralPath $item.FullName -Recurse -Force }
}
foreach ($name in @('src','public','package.json','package-lock.json','README.md','CB-RELAY-SETUP.md','config.example.json')) {
  $from = Join-Path $Source $name
  if (Test-Path -LiteralPath $from) { Copy-Item -LiteralPath $from -Destination (Join-Path $resolvedRoot $name) -Recurse -Force }
}

$configPath = Join-Path $resolvedRoot 'config.json'
if (!(Test-Path -LiteralPath $configPath)) {
  $configJson = [ordered]@{
    pairingCode = $PairingCode
    driverName = $DriverName
    dashboardPort = 4280
    dashboardHost = $(if ($EnableLan) { '0.0.0.0' } else { '127.0.0.1' })
    snapshotIntervalMs = 1000
    voice = [ordered]@{ enabled = $false; rate = 0; volume = 85; prefix = 'KAW Dispatch' }
    remote = [ordered]@{ enabled = $false; endpoint = 'https://p01--kaw-relay--4h7w2xmhzqqq.code.run/api/telemetry'; apiKey = '' }
  } | ConvertTo-Json -Depth 5
  [IO.File]::WriteAllText($configPath, $configJson, [Text.UTF8Encoding]::new($false))
}

$configText = [IO.File]::ReadAllText($configPath)
if ($configText.Length -gt 0 -and $configText[0] -eq [char]0xFEFF) {
  [IO.File]::WriteAllText($configPath, $configText.Substring(1), [Text.UTF8Encoding]::new($false))
}

Push-Location $resolvedRoot
$previousNpmCache = $env:npm_config_cache
$env:npm_config_cache = Join-Path $resolvedRoot '.npm-cache'
try {
  & $npm.Source install --omit=dev
  if ($LASTEXITCODE -ne 0) { Fail 'Dependency installation failed. Install Python 3 and Microsoft Visual Studio Build Tools with Desktop development with C++, then run the installer again.' }
  Write-Host 'Building ATS telemetry module...'
  & $npm.Source rebuild trucksim-telemetry
  if ($LASTEXITCODE -ne 0) { Fail 'The ATS telemetry module could not be built. Install Python 3 and Microsoft Visual Studio Build Tools with Desktop development with C++, then run the installer again.' }
  & $node.Source -e "require('trucksim-telemetry')"
  if ($LASTEXITCODE -ne 0) { Fail 'The ATS telemetry module did not build correctly. Install Python 3 and Microsoft Visual Studio Build Tools with Desktop development with C++, then run the installer again.' }
}
finally { $env:npm_config_cache = $previousNpmCache; Pop-Location }

$launcherScript = Join-Path $resolvedRoot 'Run-KAW-Companion.ps1'
@'
[CmdletBinding()]
param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$port = 4280
try {
  $storedConfig = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw | ConvertFrom-Json
  if ([int]$storedConfig.dashboardPort -gt 0) { $port = [int]$storedConfig.dashboardPort }
} catch {}
$baseUrl = "http://127.0.0.1:$port"
$healthUrl = "$baseUrl/api/health"
$pidFile = Join-Path $PSScriptRoot 'companion.pid'

function Test-Companion {
  try {
    $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 1
    return ($health.ok -eq $true -and $health.service -eq 'kaws-ats-companion')
  }
  catch { return $false }
}

$launchMutex = [Threading.Mutex]::new($false, 'Local\KAWATSCompanionLauncher')
$hasLaunchLock = $false
try {
  $hasLaunchLock = $launchMutex.WaitOne([TimeSpan]::FromSeconds(20))
  if (!$hasLaunchLock) { Write-Host 'Another Companion launch is still in progress.' -ForegroundColor Red; exit 1 }
  if (!(Test-Companion)) {
    $node = Get-Command node.exe -ErrorAction SilentlyContinue
    if (!$node) { Write-Host 'Node.js was not found.' -ForegroundColor Red; exit 1 }
    $entry = Join-Path $PSScriptRoot 'src\index.js'
    $nodeArguments = '"{0}"' -f $entry
    $process = Start-Process -FilePath $node.Source -ArgumentList $nodeArguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'companion.log') -RedirectStandardError (Join-Path $PSScriptRoot 'companion-error.log') -PassThru
    Set-Content -LiteralPath $pidFile -Value $process.Id -Encoding ASCII
    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
      Start-Sleep -Milliseconds 500
      if (Test-Companion) { $ready = $true; break }
      if ($process.HasExited) { break }
    }
    if (!$ready) {
      Write-Host "The Companion did not start. Check $(Join-Path $PSScriptRoot 'companion-error.log')." -ForegroundColor Red
      exit 1
    }
  }
  if (!$NoBrowser) { Start-Process $baseUrl }
}
finally {
  if ($hasLaunchLock) { $launchMutex.ReleaseMutex() }
  $launchMutex.Dispose()
}
'@ | Set-Content -LiteralPath $launcherScript -Encoding UTF8

$startScript = Join-Path $resolvedRoot 'Start-KAW-Companion.cmd'
@"
@echo off
cd /d "$resolvedRoot"
powershell.exe -NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "$launcherScript"
"@ | Set-Content -LiteralPath $startScript -Encoding ASCII

$shell = New-Object -ComObject WScript.Shell
if (!$NoAutoStart) {
  $startupLink = Join-Path ([Environment]::GetFolderPath('Startup')) 'KAW ATS Companion.lnk'
  $shortcut = $shell.CreateShortcut($startupLink); $shortcut.TargetPath = $startScript; $shortcut.WorkingDirectory = $resolvedRoot; $shortcut.Save()
}
if (!$NoDesktopShortcuts) {
  $desktop = [Environment]::GetFolderPath('Desktop')
  $shortcut = $shell.CreateShortcut((Join-Path $desktop "KAW'S ATS Companion.lnk")); $shortcut.TargetPath = $startScript; $shortcut.WorkingDirectory = $resolvedRoot; $shortcut.Save()
  $url = Join-Path $desktop "KAW'S Radio.url"; "[InternetShortcut]`r`nURL=https://p01--kaw-relay--4h7w2xmhzqqq.code.run/radio`r`n" | Set-Content -LiteralPath $url -Encoding ASCII
}

Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Uninstall-KAW-ATS-Companion.ps1') -Destination (Join-Path $resolvedRoot 'Uninstall-KAW-ATS-Companion.ps1') -Force
$powershell = Get-Command powershell.exe -ErrorAction SilentlyContinue
if (!$powershell) { Fail 'Windows PowerShell was not found.' }
& $powershell.Source -NoLogo -NoProfile -ExecutionPolicy Bypass -File $launcherScript -NoBrowser
if ($LASTEXITCODE -ne 0) { Fail "The Companion could not be started. Check $(Join-Path $resolvedRoot 'companion-error.log')." }
Write-Host "`nInstallation complete." -ForegroundColor Green
Write-Host "Version: $Version"
Write-Host "Installed to: $resolvedRoot"
Write-Host 'Companion: http://127.0.0.1:4280/'
if ($EnableLan) { Write-Host 'Private-network device access is enabled. Allow Node.js on Private networks only if Windows asks.' }
Write-Host 'Start ATS, accept its SDK warning, and load your truck.'

