@echo off
setlocal
cd /d "%~dp0"
echo Starting KAW'S ATS Playground Companion installer...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-KAW-ATS-Companion.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not complete. Leave this window open and share the error shown above.
  pause
  exit /b 1
)
echo.
pause
