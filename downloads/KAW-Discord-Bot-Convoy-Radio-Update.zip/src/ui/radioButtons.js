'use strict';
const { createHash } = require('node:crypto');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const stationId = station => createHash('sha256').update(JSON.stringify([station.url, station.by])).digest('hex').slice(0, 24);
function convoyStations(drivers) {
  return drivers.filter(d => d.t.convoyRadio?.url).map(d => {
    const station = { ...d.t.convoyRadio, by: d.driverName, title: d.t.convoyRadio.name || 'Convoy radio' };
    return { ...station, id: stationId(station) };
  });
}
function radioButtons(stations) {
  const rows = [];
  for (let i = 0; i < Math.min(stations.length, 20); i += 5) {
    rows.push(new ActionRowBuilder().addComponents(stations.slice(i, i + 5).map(station =>
      new ButtonBuilder().setCustomId(`convoy-radio:play:${station.id}`)
        .setLabel(`Send through CB: ${station.title}`.slice(0, 80)).setStyle(ButtonStyle.Primary))));
  }
  rows.push(new ActionRowBuilder().addComponents(new ButtonBuilder()
    .setCustomId('convoy-radio:stop').setLabel('Stop radio in Discord').setStyle(ButtonStyle.Secondary)));
  return rows;
}
module.exports = { stationId, convoyStations, radioButtons };
