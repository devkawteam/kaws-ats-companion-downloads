// Talks to the KAW Companion convoy relay: health, the live convoy roster (DLC, mods, events, stats,
// locations shared by drivers' Companions), the latest Companion download, and one-click setup links.

const crypto = require('node:crypto');

const STATES = ['California', 'Nevada', 'Arizona', 'New Mexico', 'Oregon', 'Washington', 'Utah', 'Idaho', 'Colorado', 'Wyoming', 'Montana', 'Texas', 'Oklahoma', 'Kansas', 'Nebraska', 'Arkansas', 'Missouri', 'Iowa', 'Louisiana', 'Illinois'];
const BASE = new Set(['California', 'Nevada', 'Arizona']);
const trim = u => String(u || '').replace(/\/+$/, '');
// Must match safeId() in relay-server/server.js
const safeId = v => String(v || '').trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-').slice(0, 64) || 'default';

function sessionCode(config) { return config.companion.sessionCode; }

async function health(url) {
  const started = Date.now();
  try {
    const r = await fetch(`${trim(url)}/health`, { signal: AbortSignal.timeout(15000) });
    const text = await r.text();
    let j = null; try { j = JSON.parse(text); } catch {}
    return { url: trim(url), up: r.ok && Boolean(j?.ok), status: r.status, latency: Date.now() - started, version: j?.version || null, uptime: j?.uptimeSeconds ?? null, sessions: j?.sessions ?? null, suspended: /suspended/i.test(text) };
  } catch (e) {
    return { url: trim(url), up: false, status: null, latency: null, error: e.name === 'TimeoutError' ? 'timed out' : e.message };
  }
}

// Full roster for the convoy session (needs the relay API key). Falls back to the backup relay.
async function roster(config) {
  const urls = [config.relayUrl, config.companion.backupRelayUrl].filter(Boolean);
  let lastError = null;
  for (const url of urls) {
    try {
      const r = await fetch(`${trim(url)}/api/roster?session=${encodeURIComponent(safeId(sessionCode(config)))}`, {
        headers: config.relayApiKey ? { authorization: `Bearer ${config.relayApiKey}`, 'accept-encoding': 'gzip' } : {},
        signal: AbortSignal.timeout(15000)
      });
      if (!r.ok) throw new Error(`relay HTTP ${r.status}`);
      const snap = await r.json();
      const drivers = (snap.drivers || []).map(d => ({ ...d, t: d.telemetry || {} }));
      return { drivers, relay: trim(url), generatedAt: snap.generatedAt };
    } catch (e) { lastError = e; }
  }
  throw new Error(lastError ? lastError.message : 'No relay configured');
}

function dlcCoverage(drivers) {
  const known = drivers.filter(d => Array.isArray(d.t.capabilities?.mapStates));
  const rows = STATES.map(state => {
    const have = known.filter(d => d.t.capabilities.mapStates.includes(state)).map(d => d.driverName);
    return { state, base: BASE.has(state), have, missing: known.filter(d => !have.includes(d.driverName)).map(d => d.driverName) };
  });
  return { known, rows, everyone: rows.filter(r => known.length && !r.missing.length).map(r => r.state), unknown: drivers.filter(d => !d.t.capabilities?.mapStates).map(d => d.driverName) };
}

function modPacks(drivers) {
  const seen = new Set();
  const packs = [];
  for (const d of drivers) {
    const m = d.t.convoyManifest;
    if (!m?.id || seen.has(m.id)) continue;
    seen.add(m.id);
    packs.push({ from: d.driverName, ...m });
  }
  return packs;
}

function events(drivers) {
  const seen = new Map();
  for (const d of drivers) for (const e of d.t.convoyEvents || []) if (e?.id && !seen.has(e.id)) seen.set(e.id, { ...e, from: d.driverName });
  const list = [...seen.values()].filter(e => ['planned', 'active'].includes(e.status));
  for (const e of list) {
    e.rsvps = drivers.map(d => ({ driverName: d.driverName, status: d.t.rsvps?.[e.id] || (d.driverName === e.host ? 'going' : null) })).filter(x => x.status);
  }
  return list.sort((a, b) => (Date.parse(a.departureTime || 0) || 9e15) - (Date.parse(b.departureTime || 0) || 9e15));
}

// Latest Companion installer from the public downloads repo.
let releaseCache = { at: 0, value: null };
async function latestRelease(config) {
  if (releaseCache.value && Date.now() - releaseCache.at < 15 * 60000) return releaseCache.value;
  const r = await fetch(`https://api.github.com/repos/${config.companion.downloadsRepo}/releases/latest`, { headers: { accept: 'application/vnd.github+json', 'user-agent': 'KAW-ATS-Bot' }, signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`GitHub HTTP ${r.status}`);
  const rel = await r.json();
  const exe = (rel.assets || []).find(a => /\.exe$/i.test(a.name));
  const sha = (rel.assets || []).find(a => /sha256/i.test(a.name));
  const value = { version: String(rel.tag_name || '').replace(/^v/i, ''), name: rel.name || rel.tag_name, url: rel.html_url, exeUrl: exe?.browser_download_url || rel.html_url, exeName: exe?.name || null, shaUrl: sha?.browser_download_url || null, publishedAt: rel.published_at, notes: String(rel.body || '').slice(0, 900) };
  releaseCache = { at: Date.now(), value };
  return value;
}

// Everything a driver needs, in one object (used for the config file and the one-click link).
function driverSetup(config, driverName) {
  return {
    endpoint: `${trim(config.relayUrl)}/api/telemetry`,
    apiKey: config.relayApiKey,
    backupEndpoints: config.companion.backupRelayUrl ? [`${trim(config.companion.backupRelayUrl)}/api/telemetry`] : [],
    pairingCode: sessionCode(config),
    driverName: String(driverName || 'ATS Driver').slice(0, 40)
  };
}

function configJson(config, driverName) {
  const s = driverSetup(config, driverName);
  return JSON.stringify({
    pairingCode: s.pairingCode, driverName: s.driverName, dashboardPort: 4280, dashboardHost: '127.0.0.1', snapshotIntervalMs: 1000,
    remote: { enabled: true, endpoint: s.endpoint, apiKey: s.apiKey, intervalMs: 3000, backupEndpoints: s.backupEndpoints },
    cb: { discordVoiceUrl: config.companion.discordVoiceUrl || '', discordInviteUrl: config.companion.discordInviteUrl || '' },
    sharing: { mods: true, manifest: true },
    alerts: { enabled: true }
  }, null, 2);
}

function connectLink(config, driverName, serverName) {
  const s = driverSetup(config, driverName);
  const payload = Buffer.from(JSON.stringify({ endpoint: s.endpoint, apiKey: s.apiKey, backupEndpoints: s.backupEndpoints, pairingCode: s.pairingCode, server: serverName })).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `http://127.0.0.1:4280/?connect=${payload}`;
}

// Public live page (same hash the relay and Companion use).
function publicLiveUrl(config) {
  const id = crypto.createHash('sha256').update(`kaw-live:${safeId(sessionCode(config))}`).digest('hex').slice(0, 12);
  return `${trim(config.relayUrl)}/live/${id}`;
}

async function radioStations(config) {
  if (!config.cbBridge?.room || !config.cbBridge?.pin) return [];
  const response = await fetch(`${trim(config.relayUrl)}/api/radio/join`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ sessionCode: config.cbBridge.room, channel: config.cbBridge.channel,
      pin: config.cbBridge.pin, memberId: 'kaw-bot-stations', author: 'KAW Discord' }),
    signal: AbortSignal.timeout(15000)
  });
  if (!response.ok) throw new Error(`CB station list returned HTTP ${response.status}`);
  const data = await response.json();
  return data.state?.stations || (data.state?.station ? [data.state.station] : []);
}

module.exports = { health, roster, radioStations, dlcCoverage, modPacks, events, latestRelease, driverSetup, configJson, connectLink, publicLiveUrl, STATES };
