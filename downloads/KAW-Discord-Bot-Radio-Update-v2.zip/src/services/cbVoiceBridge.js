const { ensureRadioRoom } = require('./radioRoom');
'use strict';

const { Readable } = require('node:stream');
const { spawn } = require('node:child_process');
const ffmpegPath = require('ffmpeg-static');
const { createCbAudio } = require('./cbAudio');
const { openStationStream, stationUrl } = require('./stationStream');
const {
  AudioPlayerStatus,
  NoSubscriberBehavior,
  StreamType,
  VoiceConnectionStatus,
  createAudioPlayer,
  createAudioResource,
  entersState,
  getVoiceConnection,
  joinVoiceChannel
} = require('@discordjs/voice');

function createCbVoiceBridge(config, hooks = {}) {
  const player = createAudioPlayer({ behaviors: { noSubscriber: NoSubscriberBehavior.Pause } });
  const state = { connection: null, guildId: null, voiceChannelId: null, eventsAbort: null, lastError: '', transmissions: 0, phase: 'idle' };

  function resourceFromStream(input, metadata) {
    const ffmpeg = spawn(ffmpegPath, [
      '-hide_banner', '-loglevel', 'error', '-protocol_whitelist', 'pipe,crypto', '-i', 'pipe:0',
      '-f', 's16le', '-ar', '48000', '-ac', '2', 'pipe:1'
    ], { windowsHide: true });
    let disposed = false;
    ffmpeg.once('close', code => {
      if (code && !disposed) {
        state.lastError = `${metadata.kind === 'station' ? 'Radio stream' : 'CB transmission'} could not be decoded.`;
        ffmpeg.stdout.destroy(new Error(state.lastError));
      }
    });
    input.on('error', error => ffmpeg.stdout.destroy(error));
    ffmpeg.on('error', error => ffmpeg.stdout.destroy(error));
    ffmpeg.stdin.on('error', () => {});
    ffmpeg.stderr.on('data', chunk => console.error('[CB VOICE FFMPEG]', String(chunk).trim()));
    input.pipe(ffmpeg.stdin);
    return {
      resource: createAudioResource(ffmpeg.stdout, { inputType: StreamType.Raw, metadata }),
      dispose() { disposed = true; input.destroy(); ffmpeg.stdin.destroy(); ffmpeg.stdout.destroy(); ffmpeg.kill(); }
    };
  }
  const audio = createCbAudio({
    player, idleEvent: AudioPlayerStatus.Idle,
    connected: () => state.connection?.state?.status === VoiceConnectionStatus.Ready,
    voiceResource(entry) {
      state.transmissions++;
      return resourceFromStream(Readable.from(Buffer.from(entry.audio, 'base64')), { kind: 'voice', id: entry.id, author: entry.author });
    },
    async stationResource(station, signal) {
      const stream = await openStationStream(station.url, signal);
      return resourceFromStream(stream, { kind: 'station', id: station.id, title: station.title });
    },
    onError(error) { state.lastError = error.message; console.error('[CB VOICE]', error.message); }
  });
  const enqueue = entry => audio.enqueue(entry);
  async function playStation(station) {
    if (!status().connected) throw new Error('Join Discord voice with /cb join first.');
    stationUrl(station.url);
    await audio.playStation(station);
    state.lastError = '';
    return status();
  }
  function stopStation() { audio.stopStation(); return status(); }

  async function listenToRelay() {
    state.eventsAbort?.abort();
    const abort = new AbortController();
    state.eventsAbort = abort;
    const room = encodeURIComponent(config.cbBridge.room);
    const channel = encodeURIComponent(config.cbBridge.channel);
    const pin = encodeURIComponent(config.cbBridge.pin);
    const url = `${config.relayUrl.replace(/\/$/, '')}/radio/events?session=${room}&channel=${channel}&pin=${pin}`;
    try {
      await ensureRadioRoom(config, 'voice');
      const response = await fetch(url, { signal: abort.signal, headers: { accept: 'text/event-stream' } });
      if (!response.ok) throw new Error(`Relay radio returned HTTP ${response.status}`);
      let pending = '';
      for await (const chunk of response.body) {
        pending += Buffer.from(chunk).toString('utf8');
        let boundary;
        while ((boundary = pending.indexOf('\n\n')) >= 0) {
          const block = pending.slice(0, boundary);
          pending = pending.slice(boundary + 2);
          const data = block.split('\n').filter(x => x.startsWith('data:')).map(x => x.slice(5).trim()).join('');
          if (!data) continue;
          try { enqueue(JSON.parse(data)); } catch {}
        }
      }
    } catch (error) {
      if (error.name === 'AbortError') return;
      state.lastError = error.message;
      console.error('[CB VOICE] Relay listener stopped:', error.message);
      if (state.connection) setTimeout(() => { if (state.connection) void listenToRelay(); }, 5000).unref();
    }
  }

  async function join(channel) {
    if (!config.cbBridge.enabled) throw new Error('The CB voice bridge is disabled in config.json.');
    if (!config.cbBridge.room || !config.cbBridge.pin) throw new Error('Set cbBridge.room and cbBridge.pin in config.json first.');
    leave();
    const existing = getVoiceConnection(channel.guild.id);
    if (existing) existing.destroy();
    state.phase = 'signalling';
    const connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
      // Not deafened, so the voice coach can measure mic levels (audio is never recorded or forwarded).
      selfDeaf: false,
      selfMute: false,
      debug: true
    });
    state.connection = connection;
    state.guildId = channel.guild.id;
    state.voiceChannelId = channel.id;
    connection.on('stateChange', (_oldState, newState) => {
      state.phase = newState.status;
      console.log(`[CB VOICE] Connection state: ${newState.status}`);
    });
    connection.on('debug', (message) => console.log(`[CB VOICE DEBUG] ${message}`));
    connection.on('error', (error) => {
      state.lastError = `Discord voice: ${error.message}`;
      console.error('[CB VOICE]', state.lastError);
    });
    try {
      await entersState(connection, VoiceConnectionStatus.Ready, 30_000);
    } catch (error) {
      const phase = connection.state.status;
      state.lastError = `Discord voice did not become ready (stopped at ${phase}). This host may be blocking the Discord voice WebSocket or UDP path.`;
      console.error(`[CB VOICE] ${state.lastError}`, error);
      connection.destroy();
      state.connection = null;
      state.guildId = null;
      state.voiceChannelId = null;
      state.phase = phase;
      throw new Error(state.lastError);
    }
    connection.subscribe(player);
    try { hooks.onReady?.(connection, channel.guild); } catch (e) { console.error('[CB VOICE] hook:', e.message); }
    connection.on(VoiceConnectionStatus.Disconnected, () => {
      state.lastError = 'Discord voice connection disconnected';
      audio.stopStation();
    });
    state.phase = 'ready';
    state.lastError = '';
    void listenToRelay();
    return status();
  }

  function leave() {
    state.eventsAbort?.abort();
    state.eventsAbort = null;
    audio.stop();
    state.connection?.destroy();
    state.connection = null;
    state.guildId = null;
    state.voiceChannelId = null;
    state.phase = 'idle';
  }

  function status() {
    return {
      enabled: config.cbBridge.enabled,
      connected: state.connection?.state?.status === VoiceConnectionStatus.Ready,
      phase: state.phase,
      voiceChannelId: state.voiceChannelId,
      room: config.cbBridge.room || 'Not configured',
      cbChannel: config.cbBridge.channel,
      ...audio.status(),
      guildId: state.guildId,
      transmissions: state.transmissions,
      lastError: state.lastError || 'None',
      ffmpegBundled: Boolean(ffmpegPath)
    };
  }

  return { join, leave, status, playStation, stopStation };
}

module.exports = { createCbVoiceBridge };

