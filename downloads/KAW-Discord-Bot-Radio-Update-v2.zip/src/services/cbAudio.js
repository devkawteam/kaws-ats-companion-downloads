'use strict';

// One Discord player: CB speech takes priority; restart the live station after speech.
function createCbAudio({ player, idleEvent, connected, voiceResource, stationResource, onError }) {
  let station = null, active = null, queue = [], generation = 0, stopping = false;
  function halt() {
    generation++;
    const previous = active;
    active = null;
    stopping = true;
    player.stop(true);
    stopping = false;
    previous?.dispose?.();
  }
  async function pump() {
    if (active || !connected()) return;
    const voice = queue.shift();
    const entry = voice || station;
    if (!entry) return;
    const item = { kind: voice ? 'voice' : 'station', generation: ++generation, abort: new AbortController() };
    item.dispose = () => item.abort.abort();
    active = item;
    try {
      const media = await (voice ? voiceResource(entry, item.abort.signal) : stationResource(entry, item.abort.signal));
      if (active !== item || generation !== item.generation) { media.dispose(); return; }
      item.resource = media.resource;
      item.dispose = () => { item.abort.abort(); media.dispose(); };
      player.play(media.resource);
    } catch (error) {
      if (active !== item) return;
      active = null;
      item.dispose();
      if (!voice) station = null;
      onError(error);
      resume();
      throw error;
    }
  }
  const resume = () => { void pump().catch(() => {}); };
  player.on(idleEvent, () => {
    if (stopping || !active) return;
    const previous = active;
    active = null;
    previous.dispose();
    // A finite station ended; don't loop a failed stream endlessly.
    if (previous.kind === 'station') station = null;
    resume();
  });
  player.on('error', error => {
    if (error.resource && active?.resource !== error.resource) return;
    if (active?.kind === 'station') station = null;
    onError(error);
    halt();
    resume();
  });
  return {
    enqueue(entry) {
      if (!entry?.audio || entry.type !== 'voice') return;
      queue = [...queue, entry].slice(-20);
      if (active?.kind === 'station') halt();
      resume();
    },
    async playStation(next) {
      station = { ...next };
      if (active?.kind === 'station') halt();
      await pump();
    },
    stopStation() { station = null; if (active?.kind === 'station') halt(); resume(); },
    stop() { station = null; queue = []; halt(); },
    status() { return { station: station ? { id: station.id, title: station.title } : null, audio: active?.kind || 'idle', queued: queue.length }; }
  };
}

module.exports = { createCbAudio };
