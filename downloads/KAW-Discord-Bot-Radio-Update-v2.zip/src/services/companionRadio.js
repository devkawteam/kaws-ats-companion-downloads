'use strict';
const relay = require('./companionRelay');
const { combinedStations } = require('../ui/radioButtons');

async function availableRadio(config, getRoster = relay.roster, getAirwaves = relay.radioStations) {
  const [convoy, cb] = await Promise.allSettled([getRoster(config), getAirwaves(config)]);
  return {
    stations: combinedStations(convoy.status === 'fulfilled' ? convoy.value.drivers : [], cb.status === 'fulfilled' ? cb.value : []),
    warnings: [convoy.status === 'rejected' ? `Convoy sharing: ${convoy.reason.message}` : null,
      cb.status === 'rejected' ? `Live Airwaves: ${cb.reason.message}` : null].filter(Boolean)
  };
}
module.exports = { availableRadio };
