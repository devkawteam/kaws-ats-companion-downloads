'use strict';
const https = require('node:https');
const http = require('node:http');
const dns = require('node:dns');
const net = require('node:net');

function publicAddress(address) {
  if (net.isIP(address) === 4) {
    const [a, b, c] = address.split('.').map(Number);
    return !(a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 168 || b === 0 || (b === 88 && c === 99))) ||
      (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) || (a === 203 && b === 0 && c === 113));
  }
  if (net.isIP(address) === 6) return /^[23]/i.test(address) && !/^2001:0*db8:/i.test(address);
  return false;
}

function stationUrl(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.href.length > 2000) {
    throw new Error('Use a direct HTTP or HTTPS radio audio stream.');
  }
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (net.isIP(host) && !publicAddress(host)) throw new Error('Radio streams must use a public internet address.');
  return url;
}

// Validate the address actually used by the socket, including every redirect.
// FFmpeg receives bytes through stdin and cannot open network/playlist URLs itself.
function publicLookup(host, options, callback) {
  dns.lookup(host, { family: options.family || 0, all: true }, (error, addresses) => {
    if (error) return callback(error);
    if (!addresses.length || addresses.some(x => !publicAddress(x.address))) {
      return callback(new Error('Radio streams must use public internet addresses.'));
    }
    if (options.all) return callback(null, addresses);
    callback(null, addresses[0].address, addresses[0].family);
  });
}

function openStationStream(value, signal, redirects = 0) {
  return new Promise((resolve, reject) => {
    let url;
    try { url = stationUrl(value); } catch (error) { reject(error); return; }
    const request = (url.protocol === 'https:' ? https : http).get(url, {
      signal, lookup: publicLookup,
      headers: { 'user-agent': 'KAW-Companion-CB-Radio/1', accept: 'audio/*, application/octet-stream' }
    }, response => {
      clearTimeout(timer);
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        response.destroy();
        if (redirects >= 5) return reject(new Error('Radio stream redirected too many times.'));
        try { resolve(openStationStream(new URL(response.headers.location, url).href, signal, redirects + 1)); }
        catch (error) { reject(error); }
        return;
      }
      if (response.statusCode !== 200 || /text\/html|mpegurl/i.test(response.headers['content-type'] || '')) {
        response.destroy();
        return reject(new Error('This station does not provide a direct playable audio stream.'));
      }
      response.setTimeout(30_000, () => response.destroy(new Error('Radio stream stopped sending audio.')));
      resolve(response);
    });
    const timer = setTimeout(() => request.destroy(new Error('Radio stream connection timed out.')), 15_000);
    timer.unref();
    request.on('error', error => { clearTimeout(timer); reject(error); });
  });
}

module.exports = { openStationStream, stationUrl, publicAddress };
