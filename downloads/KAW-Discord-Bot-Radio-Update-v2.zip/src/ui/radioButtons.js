'use strict';
const { createHash } = require('node:crypto');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const stationId = station => createHash('sha256').update(JSON.stringify([station.url, station.by])).digest('hex').slice(0, 24);
function convoyStations(drivers) {
  return drivers.filter(d => d.t.convoyRadio?.url).map(d => {
    const station = { ...d.t.convoyRadio, by: d.driverName, title: d.t.convoyRadio.name || 'Convoy radio' };
    return { ...station, id: stationId(station) };
  });
}
function combinedStations(drivers, airwaves) {
  const stations = convoyStations(drivers);
  for (const air of airwaves) {
    if (!air.url || (air.type && air.type !== 'stream')) continue;
    const station = { ...air, name: air.title || 'Live Airwaves', title: air.title || 'Live Airwaves',
      by: air.owner || air.updatedBy || 'CB driver',
      setAt: null };
    stations.push({ ...station, id: stationId(station) });
  }
  return stations.filter((s, i) => stations.findIndex(other => other.url === s.url) === i);
}
function radioButtons(stations) {
  const rows = [];
  for (let i = 0; i < Math.min(stations.length, 20); i += 5) {
    rows.push(new ActionRowBuilder().addComponents(stations.slice(i, i + 5).map(station =>
      new ButtonBuilder().setCustomId(`convoy-radio:play:${station.id}`)
        .setLabel(`Send through CB: ${station.title}`.slice(0, 80)).setStyle(ButtonStyle.Primary))));
  }
  rows.push(new ActionRowBuilder().addComponents(new ButtonBuilder()
    .setCustomId('convoy-radio:stop').setLabel('Stop radio in Discord').setStyle(ButtonStyle.Secondary)));
  return rows;
}
function radioView({ stations, warnings }) {
  const lines = stations.length ? stations.slice(0, 20).map(s => `📻 **${s.title}** — shared by ${s.by}`).join('\n\n') :
    'No shared audio station found. In **Live Airwaves**, join your CB room and click **AIR ON MY STATION**. In **Convoy radio**, click **Share with convoy** and enable convoy sharing. Listening or previewing alone does not share a station. The bot must use the same CB room or convoy code.';
  return { description: [lines, ...warnings].join('\n\n').slice(0, 4000), components: stations.length ? radioButtons(stations) : [] };
}
module.exports = { stationId, convoyStations, combinedStations, radioButtons, radioView };
