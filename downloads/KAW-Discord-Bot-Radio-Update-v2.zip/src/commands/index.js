const {
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  PermissionFlagsBits
} = require('discord.js');

const { availableRadio } = require('../services/companionRadio');
const { radioView } = require('../ui/radioButtons');
const { base, atsHubEmbed, profileEmbed } = require('../ui/embeds');
const { hubButtons, convoyButtons, gameRoleButtons } = require('../ui/components');
const { formatNumber, truncate } = require('../utils/discord');
const { isStaff, canCreateConvoy } = require('../utils/permissions');
const tmp = require('../services/truckersmp');
const { generateDispatch } = require('../services/dispatch');
const serverSetup = require('../services/discordServerSetup');
const { queryAtsServer } = require('../services/atsServer');

function achievementText(items) {
  if (!items.length) return 'No achievements unlocked yet.';
  return items.map((a) => `**${a.name}** — ${a.description} (+${formatNumber(a.xp)} XP)`).join('\n');
}

function createCommands({ config, store, cbVoiceBridge, discordRelayBridge }) {
  return [
    {
      data: new SlashCommandBuilder().setName('ats').setDescription('Open the ATS Playground Driver Operations Hub.'),
      async execute({ interaction }) {
        await interaction.reply({ embeds: [atsHubEmbed(store)], components: hubButtons() });
      }
    },

    {
      data: new SlashCommandBuilder().setName('help').setDescription('Show ATS Playground commands and features.'),
      async execute({ interaction }) {
        await interaction.reply({
          embeds: [
            base('ATS Playground • Command Center')
              .setDescription([
                '**Companion** — `/companion setup` (download + one-click connect), `/companion config`, `/companion download`, `/companion features`, `/companion voice`',
                '**Convoy Hub (live)** — `/hub who`, `/hub where`, `/hub dlc`, `/hub mods`, `/hub events`, `/hub standings`, `/hub radio`, `/hub page`',
                '**Relay** — `/relay status`',
                '**Core** — `/ats`, `/status`, `/help`, `/support`, `/server preview`',
                '**Local AI** — `/ai status`, `/ai ask`, `/ai briefing` (staff)',
                '**Driver** — `/profile`, `/stats`, `/rank`, `/achievements`, `/records`, `/challenges`',
                '**Trips** — `/trip log`, `/trip history`',
                '**Operations** — `/dispatch`, `/convoy`',
                '**Leaderboards** — `/leaderboard`',
                '**Telemetry** — `/telemetry link`, `/telemetry status`',
                '**Companion Radio** — `/nowplaying`, `/cb pair`, `/cb join`, `/cb leave`, `/cb status`',
                '**TruckersMP** — `/tmp servers`, `/tmp version`, `/tmp time`, `/tmp events`, `/tmp player`',
                '',
                'The button-driven **/ats** hub is the recommended interface.'
              ].join('\n'))
          ],
          ephemeral: true
        });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('support').setDescription('Get ATS, ETS2 and Companion troubleshooting help.')
        .addStringOption((o) => o.setName('topic').setDescription('What do you need help with?').setRequired(true).addChoices(
          { name: 'Disconnected from Convoy', value: 'disconnect' },
          { name: 'Kicked or Disconnected?', value: 'kick' },
          { name: 'Mods / Version Mismatch', value: 'mods' },
          { name: 'Lag, Freezing or Low FPS', value: 'performance' },
          { name: 'Companion / CB Radio', value: 'companion' },
          { name: 'Find and Send Game Log', value: 'logs' }
        )),
      async execute({ interaction }) {
        const topic = interaction.options.getString('topic');
        const guides = {
          disconnect: base('ATS/ETS2 Support • Convoy Disconnect').setDescription([
            'A generic **connection lost** message does not mean an administrator kicked you.',
            '',
            '**Try these in order:**',
            '1. Restart Steam and the game, then rejoin.',
            '2. Turn off VPNs and restart your router.',
            '3. Use Ethernet or strong 5 GHz Wi-Fi if available.',
            '4. Confirm everyone uses the same game version and is not on a beta branch.',
            '5. Test once with every mod disabled.',
            '6. Verify the game files in Steam.',
            '7. Allow Steam and ATS/ETS2 through Windows Firewall.',
            '',
            'If only one driver drops while everyone else stays connected, the problem is usually that driver’s connection or computer. Use `/support topic:Find and Send Game Log` after the next disconnect.'
          ].join('\n')),
          kick: base('ATS/ETS2 Support • Kicked or Disconnected?').setDescription([
            '**Disconnected:** normally appears as “connection to the server was lost.” It can be caused by Wi-Fi, Internet routing, firewall, game/mod mismatch, or a server interruption.',
            '',
            '**Admin action:** should be confirmed from the server’s administration/audit records. A basic server line that only says `player disconnected` does **not** prove an administrator kicked the player.',
            '',
            'Save the player’s `game.log.txt` immediately after the incident and ask staff to compare its time with the server log.'
          ].join('\n')),
          mods: base('ATS/ETS2 Support • Mods and Versions').setDescription([
            '1. Confirm every driver is on the same ATS/ETS2 version.',
            '2. Leave Steam beta participation set to **None** unless the convoy specifically uses a beta.',
            '3. Match required mods and their versions.',
            '4. Confirm required map DLC is available.',
            '5. Run one clean test with all mods disabled.',
            '6. Dedicated-server owners should regenerate the server package files after changing mods or DLC.',
            '',
            'If the clean test works, restore mods in small groups until the incompatible item is found.'
          ].join('\n')),
          performance: base('ATS/ETS2 Support • Lag, Freezing and FPS').setDescription([
            '• Close overlays and unnecessary background programs.',
            '• Update the graphics driver and restart Windows.',
            '• Lower mirror distance/quality, scaling, shadows and traffic-heavy settings first.',
            '• Check that the game uses the dedicated graphics card.',
            '• Verify game files and test without mods.',
            '• Keep enough free space on the Windows/game drive.',
            '• For network lag, test Ethernet and close downloads or cloud synchronization.',
            '',
            'A low frame rate is a computer-performance issue; rubber-banding or multiplayer drops are usually network/server issues.'
          ].join('\n')),
          companion: base('KAW Companion Support').setDescription([
            '• Confirm the Companion shows **Telemetry Connected** after ATS/ETS2 loads into the truck.',
            '• For CB access, run `/cb pair`, enter the private 8-character code, and choose **Remember CB access** on a personal device.',
            '• Use the secure HTTPS radio page and allow microphone access in the browser.',
            '• If audio is silent, press **Enable / Resync Audio** once and check the CB and station volume controls.',
            '• Restart the Companion from its Start Menu shortcut if its local dashboard does not open.',
            '',
            'The Companion cannot kick a driver from an ATS/ETS2 Convoy server; its telemetry and radio connections are separate.'
          ].join('\n')),
          logs: base('ATS/ETS2 Support • Send the Game Log').setDescription([
            '**Immediately after the problem:** close the game and do not reopen it before copying the log.',
            '',
            '**ATS:** `Documents\\American Truck Simulator\\game.log.txt`',
            '**ETS2:** `Documents\\Euro Truck Simulator 2\\game.log.txt`',
            '',
            'Upload the file to the designated technical-support channel with:',
            '• What happened',
            '• Approximate time',
            '• Server/convoy name',
            '• Whether other drivers disconnected',
            '• Game version and whether mods were enabled',
            '',
            'Never upload account passwords, Discord tokens, API keys, or private CB room PINs.'
          ].join('\n'))
        };
        return interaction.reply({ embeds: [guides[topic]], ephemeral: true });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('server').setDescription('Build and manage the ATS/ETS2 Discord community section.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand((s) => s.setName('preview').setDescription('Preview what ATS/ETS2 setup would create without changing anything.'))
        .addSubcommand((s) => s.setName('setup').setDescription('Create missing ATS/ETS2 roles, categories and channels.'))
        .addSubcommand((s) => s.setName('roles').setDescription('Post the ATS/ETS2 driver role-selection panel in this channel.')),
      async execute({ interaction }) {
        if (!interaction.guild) return interaction.reply({ content: 'This command must be used inside the Discord server.', ephemeral: true });
        const sub = interaction.options.getSubcommand();
        if (sub === 'preview') {
          const p = serverSetup.preview(interaction.guild);
          const categoryLines = p.categories.map(category => `**${category.name}** — ${category.existing ? 'reuse' : 'create'} • ${category.channels.filter(item => !item.existing).length} new channels`);
          return interaction.reply({ embeds: [base('ATS/ETS2 Discord Build • Preview').setDescription([
            `Roles: **${p.createRoles} create** • ${p.reuseRoles} reuse`,
            `Categories: **${p.createCategories} create**`,
            `Channels: **${p.createChannels} create** • ${p.reuseChannels} reuse`,
            '', ...categoryLines, '',
            'Nothing has been changed. Run `/server setup` when ready. Existing matching roles and channels are reused; nothing is deleted.'
          ].join('\n'))], ephemeral: true });
        }
        if (sub === 'roles') {
          const roles = serverSetup.resolveGameRoles(interaction.guild);
          if (!roles.ats || !roles.ets2) return interaction.reply({ content: 'Run `/server setup` first so the ATS and ETS2 roles exist.', ephemeral: true });
          await interaction.channel.send({ embeds: [base('Choose Your Trucking Games').setDescription([
            'Select the game areas you want to access. You can change your selection at any time.',
            '',
            '🚚 **ATS Driver** — American Truck Simulator operations',
            '🚛 **ETS2 Driver** — Euro Truck Simulator 2 operations',
            '🌍 **Both Games** — access both trucking communities'
          ].join('\n'))], components: gameRoleButtons() });
          return interaction.reply({ content: 'The ATS/ETS2 role-selection panel was posted in this channel.', ephemeral: true });
        }
        await interaction.deferReply({ ephemeral: true });
        try {
          const result = await serverSetup.apply(interaction.guild);
          return interaction.editReply({ embeds: [base('ATS/ETS2 Discord Build • Complete').addFields(
            { name: 'Roles', value: `Created ${result.createdRoles.length} • Reused ${result.reusedRoles.length}`, inline: true },
            { name: 'Categories', value: `Created ${result.createdCategories.length} • Reused ${result.reusedCategories.length}`, inline: true },
            { name: 'Channels', value: `Created ${result.createdChannels.length} • Reused ${result.reusedChannels.length}`, inline: true },
            { name: 'Next Step', value: 'Open `driver-role-selection` and run `/server roles` there to post the game-selection buttons.', inline: false }
          )] });
        } catch (error) {
          return interaction.editReply({ content: `ATS/ETS2 setup could not finish: ${error.message}` });
        }
      }
    },

    {
      data: new SlashCommandBuilder().setName('status').setDescription('Show bot and ATS Playground platform health.'),
      async execute({ interaction, client }) {
        await interaction.deferReply();
        let api = 'Operational';
        let latency = null;
        try {
          const health = await tmp.health();
          latency = health.latency;
        } catch {
          api = 'Unavailable';
        }
        const stats = store.getCommunityStats();
        const bridge = discordRelayBridge.status();
        const voice = cbVoiceBridge.status();
        await interaction.editReply({
          embeds: [base('ATS Playground • System Status').addFields(
            { name: 'Discord Bot', value: 'ONLINE', inline: true },
            { name: 'Discord Ping', value: `${client.ws.ping} ms`, inline: true },
            { name: 'TruckersMP API', value: latency ? `${api} • ${latency} ms` : api, inline: true },
            { name: 'Storage', value: 'ONLINE • Persistent JSON', inline: true },
            { name: 'Tracked Trips', value: formatNumber(stats.trips), inline: true },
            { name: 'Tracked Miles', value: `${formatNumber(stats.miles)} mi`, inline: true },
            { name: 'Companion Chat Bridge', value: bridge.configured ? `READY • <#${bridge.discordChannelId}>` : 'Needs configuration', inline: true },
            { name: 'CB Voice Bridge', value: voice.connected ? `ACTIVE • <#${voice.voiceChannelId}>` : voice.enabled ? 'Ready for /cb join' : 'Disabled in config', inline: true }
          )]
        });
      }
    },

    {
      data: new SlashCommandBuilder().setName('nowplaying').setDescription('Show every station currently available in the KAW Companion.'),
      async execute({ interaction }) {
        await interaction.deferReply();
        const view = radioView(await availableRadio(config));
        return interaction.editReply({ embeds: [base("KAW'S Radio • Now Playing", view.description)], components: view.components, allowedMentions: { parse: [] } });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('Manage ATS Playground driver profiles.')
        .addSubcommand((s) => s.setName('view').setDescription('View a driver profile.').addUserOption((o) => o.setName('driver').setDescription('Driver to view.')))
        .addSubcommand((s) => s.setName('setup').setDescription('Create or edit your driver profile.')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'setup') {
          const existing = store.getProfile(interaction.user.id) || {};
          const modal = new ModalBuilder().setCustomId('profile:setup').setTitle('ATS Playground Driver Profile');
          const fields = [
            ['driverName', 'Driver / Display Name', true, existing.driverName || interaction.user.username],
            ['preferredTruck', 'Preferred Truck', false, existing.preferredTruck || ''],
            ['homeGarage', 'Home Garage / City', false, existing.homeGarage || ''],
            ['truckersMpId', 'TruckersMP ID or SteamID64', false, existing.truckersMpId || '']
          ].map(([id, label, required, value]) =>
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId(id).setLabel(label).setStyle(TextInputStyle.Short)
                .setRequired(required).setValue(value)
            )
          );
          modal.addComponents(...fields);
          return interaction.showModal(modal);
        }

        const user = interaction.options.getUser('driver') || interaction.user;
        return interaction.reply({
          embeds: [profileEmbed(user, store.getProfile(user.id), store.getUserStats(user.id))]
        });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('stats').setDescription('Show ATS Playground career statistics.')
        .addUserOption((o) => o.setName('driver').setDescription('Driver to view.')),
      async execute({ interaction }) {
        const user = interaction.options.getUser('driver') || interaction.user;
        const s = store.getUserStats(user.id);
        await interaction.reply({
          embeds: [base(`${user.username} • Career Statistics`)
            .setThumbnail(user.displayAvatarURL())
            .addFields(
              { name: 'Rank', value: s.rank.name, inline: true },
              { name: 'XP', value: formatNumber(s.xp), inline: true },
              { name: 'Tracked Miles', value: `${formatNumber(s.miles)} mi`, inline: true },
              { name: 'Trips', value: formatNumber(s.trips), inline: true },
              { name: 'Perfect Trips', value: formatNumber(s.perfectTrips), inline: true },
              { name: 'Convoys', value: formatNumber(s.convoys), inline: true },
              { name: 'Dispatches', value: formatNumber(s.dispatches), inline: true },
              { name: 'Career Income', value: `$${formatNumber(s.income)}`, inline: true },
              { name: 'Fuel Logged', value: `${formatNumber(s.fuelGallons)} gal`, inline: true }
            )]
        });
      }
    },

    {
      data: new SlashCommandBuilder().setName('rank').setDescription('Show your ATS Playground XP rank.'),
      async execute({ interaction }) {
        const s = store.getUserStats(interaction.user.id);
        const nextText = s.rank.next
          ? `${formatNumber(s.rank.next.xp - s.xp)} XP until **${s.rank.next.name}**`
          : 'You have reached the highest current rank.';
        await interaction.reply({
          embeds: [base(`${interaction.user.username} • ${s.rank.name}`, `**${formatNumber(s.xp)} XP**\n${nextText}`)]
        });
      }
    },

    {
      data: new SlashCommandBuilder().setName('achievements').setDescription('View ATS Playground achievements.'),
      async execute({ interaction }) {
        const unlocked = store.getAchievements(interaction.user.id);
        const defs = store.getAllAchievementDefinitions();
        const locked = Object.entries(defs)
          .filter(([id]) => !unlocked.some((a) => a.id === id))
          .map(([, a]) => `• ${a.name}`)
          .join('\n') || 'All current achievements unlocked.';
        await interaction.reply({
          embeds: [base('ATS Playground • Achievements')
            .addFields(
              { name: `Unlocked (${unlocked.length})`, value: achievementText(unlocked).slice(0, 1024) || 'None' },
              { name: 'Still Locked', value: locked.slice(0, 1024) }
            )]
        });
      }
    },

    {
      data: new SlashCommandBuilder().setName('records').setDescription('View your ATS Playground personal records.'),
      async execute({ interaction }) {
        const r = store.getPersonalRecords(interaction.user.id);
        if (!r) return interaction.reply({ content: 'You need at least one tracked trip before records can be calculated.', ephemeral: true });
        await interaction.reply({
          embeds: [base(`${interaction.user.username} • Personal Records`).addFields(
            { name: 'Longest Trip', value: `${r.longest.origin || '?'} → ${r.longest.destination || '?'}\n${formatNumber(r.longest.miles)} mi`, inline: true },
            { name: 'Highest Paying', value: `$${formatNumber(r.richest.income)}\n${r.richest.cargo || 'Unknown cargo'}`, inline: true },
            { name: 'Best Fuel Economy', value: r.bestFuel ? `${r.bestFuel.mpg.toFixed(2)} MPG` : 'Not enough fuel data', inline: true }
          )]
        });
      }
    },

    {
      data: new SlashCommandBuilder().setName('challenges').setDescription('View your active ATS Playground challenges.'),
      async execute({ interaction }) {
        const challenges = store.getChallenges(interaction.user.id);
        const lines = challenges.map((c) => {
          const pct = Math.min(100, Math.round((c.progress / c.target) * 100));
          return `**${c.name}** — ${c.description}\n${formatNumber(c.progress)}/${formatNumber(c.target)} (${pct}%) • +${formatNumber(c.rewardXp)} XP`;
        });
        await interaction.reply({ embeds: [base('ATS Playground • Challenges', lines.join('\n\n'))] });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('trip').setDescription('Track ATS Playground trips.')
        .addSubcommand((s) => s.setName('log').setDescription('Manually log a completed ATS trip.'))
        .addSubcommand((s) => s.setName('history').setDescription('View your latest tracked trips.')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'log') {
          const modal = new ModalBuilder().setCustomId('trip:log').setTitle('Log ATS Trip');
          const fields = [
            ['route', 'Route (Origin → Destination)', TextInputStyle.Short, true],
            ['cargo', 'Cargo / Load', TextInputStyle.Short, true],
            ['miles', 'Miles Driven', TextInputStyle.Short, true],
            ['income', 'Income (numbers only)', TextInputStyle.Short, false],
            ['details', 'Damage % / Fuel Gallons / Class', TextInputStyle.Paragraph, false]
          ].map(([id, label, style, required]) =>
            new ActionRowBuilder().addComponents(
              new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required)
            )
          );
          modal.addComponents(...fields);
          return interaction.showModal(modal);
        }

        const trips = store.getTripsForUser(interaction.user.id).slice(0, 10);
        const description = trips.length
          ? trips.map((t) => `**${t.id}** • ${t.origin || '?'} → ${t.destination || '?'}\n${formatNumber(t.miles)} mi • ${t.cargo || 'Unknown cargo'} • +${formatNumber(t.xpEarned)} XP`).join('\n\n')
          : 'No tracked trips yet.';
        return interaction.reply({ embeds: [base(`${interaction.user.username} • Trip History`, description)] });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('leaderboard').setDescription('View ATS Playground community leaderboards.')
        .addStringOption((o) => o.setName('metric').setDescription('Leaderboard category.').setRequired(true).addChoices(
          { name: 'XP', value: 'xp' },
          { name: 'Miles', value: 'miles' },
          { name: 'Trips', value: 'trips' },
          { name: 'Income', value: 'income' },
          { name: 'Perfect Trips', value: 'perfectTrips' },
          { name: 'Convoys', value: 'convoys' }
        )),
      async execute({ interaction }) {
        const metric = interaction.options.getString('metric');
        const rows = store.getLeaderboard(metric);
        const labels = { xp: 'XP', miles: 'Miles', trips: 'Trips', income: 'Income', perfectTrips: 'Perfect Trips', convoys: 'Convoys' };
        const lines = rows.length ? rows.map((r, i) => {
          const raw = r[metric] || 0;
          const value = metric === 'income' ? `$${formatNumber(raw)}` : metric === 'miles' ? `${formatNumber(raw)} mi` : formatNumber(raw);
          return `**${i + 1}.** <@${r.userId}> — ${value}`;
        }).join('\n') : 'No ranked driver data yet.';
        await interaction.reply({ embeds: [base(`ATS Playground • ${labels[metric]} Leaderboard`, lines)] });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('dispatch').setDescription('Request a virtual ATS Playground dispatch.')
        .addStringOption((o) => o.setName('type').setDescription('Type of dispatch.').setRequired(true).addChoices(
          { name: 'Random', value: 'random' }, { name: 'Quick Haul', value: 'quick' },
          { name: 'Long Haul', value: 'longhaul' }, { name: 'Heavy Haul', value: 'heavy' },
          { name: 'Oversize', value: 'oversize' }, { name: 'Hazmat', value: 'hazmat' }
        )),
      async execute({ interaction }) {
        const mission = generateDispatch(interaction.options.getString('type'));
        const item = await store.createDispatch({ ...mission, userId: interaction.user.id, guildId: interaction.guildId });
        await interaction.reply({
          embeds: [base(`DISPATCH ${item.id}`).setDescription(`Assigned to <@${interaction.user.id}>`).addFields(
            { name: 'Origin', value: item.origin, inline: true }, { name: 'Destination', value: item.destination, inline: true },
            { name: 'Cargo', value: item.cargo, inline: true }, { name: 'Estimated Distance', value: `${formatNumber(item.miles)} mi`, inline: true },
            { name: 'Classification', value: item.type.toUpperCase(), inline: true }, { name: 'Bonus XP', value: `+${formatNumber(item.bonusXp)}`, inline: true }
          )]
        });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('convoy').setDescription('ATS Playground convoy operations.')
        .addSubcommand((s) => s.setName('join').setDescription('Show the private ATS server joining instructions.'))
        .addSubcommand((s) => s.setName('live').setDescription('Show the live ATS dedicated-server player count.'))
        .addSubcommand((s) => s.setName('list').setDescription('View upcoming convoys.'))
        .addSubcommand((s) => s.setName('create').setDescription('Create a convoy event (staff).')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'join') {
          if (!config.atsServer.searchId) return interaction.reply({ content: 'The ATS Convoy Search ID has not been configured yet.', ephemeral: true });
          return interaction.reply({ embeds: [base('KAW ATS Convoy • How to Join').setDescription([
            `**Server:** ${config.atsServer.name}`,
            `**Session Search ID:** \`${config.atsServer.searchId}\``,
            `**Password:** \`${config.atsServer.password || 'No password'}\``,
            '',
            '**Inside American Truck Simulator:**',
            '1. Open **Convoys** from the main menu.',
            '2. Paste the complete Session Search ID into the search box, including `/101`.',
            '3. Select **KAWs ATS Playground**.',
            '4. Enter the password exactly as shown above—it is case-sensitive.',
            '5. Join the session and meet the convoy in Discord.',
            '',
            'Use `/convoy live` to check how many drivers are currently connected.'
          ].join('\n'))], ephemeral: true });
        }
        if (sub === 'live') {
          if (!config.atsServer.host || !config.atsServer.queryPort) {
            return interaction.reply({ content: 'The ATS server status connection has not been configured yet.', ephemeral: true });
          }
          await interaction.deferReply();
          try {
            const server = await queryAtsServer(config.atsServer);
            const maximum = server.maxPlayers || config.atsServer.maxPlayers || '?';
            return interaction.editReply({ embeds: [base('KAW ATS Convoy • Live Server').addFields(
              { name: 'Status', value: '🟢 ONLINE', inline: true },
              { name: 'Drivers Live', value: `**${server.players}/${maximum}**`, inline: true },
              { name: 'Server Ping', value: `${server.latency} ms`, inline: true },
              { name: 'Server', value: server.name || 'KAWs ATS Playground', inline: false },
              { name: 'Game Version', value: server.version || 'Not reported', inline: true },
              { name: 'Driver Names', value: 'The public server query reliably reports the count. Names require server-log monitoring and will be added separately.', inline: false }
            )] });
          } catch (error) {
            return interaction.editReply({ embeds: [base('KAW ATS Convoy • Server Unreachable').setDescription([
              'The bot could not reach the ATS query port.',
              `**Details:** ${error.message}`,
              '',
              'This does not necessarily mean the game server is offline; confirm the ZAP server is running and that its query port is publicly reachable.'
            ].join('\n'))] });
          }
        }
        if (sub === 'create') {
          if (!canCreateConvoy(interaction, config)) return interaction.reply({ content: 'You need the **ATS** or **ATS Driver** role (or staff) to create a convoy.', ephemeral: true });
          const modal = new ModalBuilder().setCustomId('convoy:create').setTitle('Create ATS Playground Convoy');
          // Max lengths keep every part of the convoy post inside Discord's embed limits.
          const fields = [
            ['title', 'Convoy Name', TextInputStyle.Short, true, 100],
            ['route', 'Route (Origin → Destination)', TextInputStyle.Short, true, 200],
            ['schedule', 'Date / Meet Time / Departure Time', TextInputStyle.Short, true, 200],
            ['details', 'Server / DLC / Rules / Requirements', TextInputStyle.Paragraph, false, 3900]
          ].map(([id, label, style, required, max]) =>
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(style).setRequired(required).setMaxLength(max))
          );
          modal.addComponents(...fields);
          return interaction.showModal(modal);
        }
        const convoys = store.getConvoys().slice(0, 10);
        const description = convoys.length ? convoys.map((c) => {
          const attendees = (c.attendees || []);
          const ready = attendees.filter((a) => typeof a === 'object' && a.status === 'READY').length;
          return `**${c.id} • ${c.title}**\n${c.route} • ${c.schedule}\nDrivers: ${attendees.length} • Ready: ${ready}`;
        }).join('\n\n') : 'No convoys have been scheduled yet.';
        await interaction.reply({ embeds: [base('ATS Playground • Convoy Operations', description)] });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('cb').setDescription('Control the Companion CB to Discord voice bridge.')
        .addSubcommand((s) => s.setName('pair').setDescription('Generate a private one-time code to connect your Companion device.'))
        .addSubcommand((s) => s.setName('join').setDescription('Join your current Discord voice channel and relay Companion CB audio.'))
        .addSubcommand((s) => s.setName('leave').setDescription('Stop the CB bridge and leave Discord voice.'))
        .addSubcommand((s) => s.setName('status').setDescription('Show CB bridge configuration and runtime health.')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'pair') {
          if (!config.cbBridge.enabled || !config.cbBridge.room || !config.cbBridge.pin) {
            return interaction.reply({ content: 'Companion CB pairing is not configured yet.', ephemeral: true });
          }
          await interaction.deferReply({ ephemeral: true });
          try {
            const response = await fetch(`${config.relayUrl.replace(/\/$/, '')}/api/radio/pair/create`, {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ sessionCode: config.cbBridge.room, channel: config.cbBridge.channel, pin: config.cbBridge.pin })
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok) throw new Error(data.error || `Relay returned HTTP ${response.status}`);
            const expires = Math.floor(new Date(data.expiresAt).getTime() / 1000);
            return interaction.editReply({ embeds: [base('KAW Companion CB • Pair This Device').setDescription([
              `Enter this private one-time code in the Companion CB panel:`,
              `# ${data.code}`,
              `Expires <t:${expires}:R> and can only be used once.`,
              '',
              'On a trusted personal device, enable **Remember CB access on this device** after pairing so future refreshes connect without reopening a setup file. The permanent PIN is not stored in the browser.',
              'Do not post this code in a public channel.'
            ].join('\n'))] });
          } catch (error) {
            return interaction.editReply({ content: `A pairing code could not be generated: ${error.message}` });
          }
        }
        if (sub === 'status') {
          const s = cbVoiceBridge.status();
          return interaction.reply({ embeds: [base('KAW Companion CB • Discord Voice').addFields(
            { name: 'Feature', value: s.enabled ? 'ENABLED' : 'DISABLED IN CONFIG', inline: true },
            { name: 'Discord Voice', value: s.connected ? `<#${s.voiceChannelId}>` : `Not connected • ${s.phase}`, inline: true },
            { name: 'Companion CB', value: `${s.room} • CH ${s.cbChannel}`, inline: true },
            { name: 'Audio Runtime', value: s.ffmpegBundled ? 'Bundled FFmpeg ready' : 'FFmpeg missing', inline: true },
            { name: 'Discord radio', value: s.station ? `${s.station.title} • ${s.audio === 'voice' ? 'paused for CB speech' : 'playing'}` : 'Off', inline: true },
            { name: 'Voice Bursts Played', value: String(s.transmissions), inline: true },
            { name: 'Last Error', value: s.lastError.slice(0, 1024), inline: false }
          )], ephemeral: true });
        }
        if (!isStaff(interaction, config)) return interaction.reply({ content: 'You need ATS Playground staff permissions to control the CB voice bridge.', ephemeral: true });
        if (sub === 'leave') {
          cbVoiceBridge.leave();
          return interaction.reply({ content: 'The Companion CB bridge was stopped and the bot left Discord voice.' });
        }
        const channel = interaction.member?.voice?.channel;
        if (!channel) return interaction.reply({ content: 'Join the Discord voice channel you want the bot to use, then run `/cb join` again.', ephemeral: true });
        const permissions = channel.permissionsFor(interaction.guild.members.me);
        if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions.has(PermissionFlagsBits.Connect) || !permissions.has(PermissionFlagsBits.Speak)) {
          return interaction.reply({ content: 'The bot needs View Channel, Connect, and Speak permissions in that voice channel.', ephemeral: true });
        }
        await interaction.deferReply();
        try {
          const s = await cbVoiceBridge.join(channel);
          return interaction.editReply({ embeds: [base('KAW Companion CB • BRIDGE ACTIVE').setDescription(`Listening to **${s.room} • CB channel ${s.cbChannel}** and playing new Companion CB transmissions in ${channel}.\n\nThis first test bridge is one-way: Companion CB → Discord voice.`)] });
        } catch (error) {
          return interaction.editReply({ content: `The voice bridge could not start: ${error.message}` });
        }
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('telemetry').setDescription('Manage future ATS live telemetry integration.')
        .addSubcommand((s) => s.setName('link').setDescription('Generate your private telemetry pairing code.'))
        .addSubcommand((s) => s.setName('status').setDescription('Show your telemetry link status.'))
        .addSubcommand((s) => s.setName('setup').setDescription('Show ATS Companion installation steps.')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'setup') {
          return interaction.reply({
            embeds: [base('ATS Playground • Companion Setup').setDescription([
              '**1.** Install the ATS Playground Companion on your Windows gaming PC.',
              '**2.** Install a compatible SCS telemetry shared-memory plugin into ATS `bin/win_x64/plugins`.',
              '**3.** Run `/telemetry link` here to generate your private pairing code.',
              '**4.** Put that code into the Companion `config.json`.',
              '**5.** Start ATS, accept the SDK warning, then start the Companion.',
              '**6.** Open `http://127.0.0.1:4280` to verify live truck data.',
              '',
              'v0.4.0 validates telemetry locally. Remote Discord streaming is the next relay phase.'
            ].join('\n'))],
            ephemeral: true
          });
        }
        if (sub === 'link') {
          const link = await store.createTelemetryLink(interaction.user.id);
          return interaction.reply({
            embeds: [base('ATS Playground • Telemetry Pairing')
              .setDescription('This pairing code is for the upcoming ATS Playground Companion. Keep it private.')
              .addFields(
                { name: 'Pairing Code', value: `\`${link.token}\`` },
                { name: 'Status', value: 'Prepared • Companion not released yet', inline: true }
              )],
            ephemeral: true
          });
        }
        const link = store.getTelemetryLink(interaction.user.id);
        return interaction.reply({
          embeds: [base('ATS Playground • Telemetry Status').addFields(
            { name: 'Linked', value: link?.active ? 'Pairing code generated' : 'No', inline: true },
            { name: 'Last Seen', value: link?.lastSeenAt || 'Never', inline: true },
            { name: 'Companion', value: 'Future build', inline: true }
          )],
          ephemeral: true
        });
      }
    },

    {
      data: new SlashCommandBuilder()
        .setName('tmp').setDescription('Live TruckersMP information.')
        .addSubcommand((s) => s.setName('servers').setDescription('Show live TruckersMP server status.'))
        .addSubcommand((s) => s.setName('version').setDescription('Show current supported ATS/ETS2 versions.'))
        .addSubcommand((s) => s.setName('time').setDescription('Show TruckersMP in-game time value.'))
        .addSubcommand((s) => s.setName('events').setDescription('Show current/upcoming TruckersMP events.'))
        .addSubcommand((s) => s.setName('player').setDescription('Look up a TruckersMP player.').addStringOption((o) => o.setName('id').setDescription('TruckersMP ID or SteamID64.').setRequired(true))),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (sub === 'servers') {
          const servers = await tmp.getServers();
          const lines = servers.slice(0, 15).map((s) => `**${s.name}** — ${s.online ? 'ONLINE' : 'OFFLINE'} — ${formatNumber(s.players)}/${formatNumber(s.maxplayers)}`);
          return interaction.editReply({ embeds: [base('TruckersMP • Live Servers', lines.join('\n') || 'No server data returned.')] });
        }

        if (sub === 'version') {
          const v = await tmp.getVersion();
          return interaction.editReply({ embeds: [base('TruckersMP • Compatibility').addFields(
            { name: 'TruckersMP', value: `${v.name || 'Unknown'} (${v.numeric || 'n/a'})`, inline: true },
            { name: 'ATS Supported', value: v.supported_ats_game_version || 'Unknown', inline: true },
            { name: 'ETS2 Supported', value: v.supported_game_version || 'Unknown', inline: true },
            { name: 'Stage', value: v.stage || 'Unknown', inline: true }
          )] });
        }

        if (sub === 'time') {
          const value = await tmp.getGameTime();
          return interaction.editReply({ embeds: [base('TruckersMP • Game Time', `Raw in-game minute counter: **${formatNumber(value.game_time)}**`)] });
        }

        if (sub === 'events') {
          const events = await tmp.getEvents();
          const combined = [
            ...(events.now || []).map((e) => ({ ...e, bucket: 'NOW' })),
            ...(events.today || []).map((e) => ({ ...e, bucket: 'TODAY' })),
            ...(events.featured || []).map((e) => ({ ...e, bucket: 'FEATURED' })),
            ...(events.upcoming || []).map((e) => ({ ...e, bucket: 'UPCOMING' }))
          ];
          const seen = new Set();
          const unique = combined.filter((e) => {
            const key = e.id ?? e.name;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          }).slice(0, 10);
          const lines = unique.map((e) => `**[${e.bucket}] ${truncate(e.name || e.title || `Event ${e.id}`, 80)}**`);
          return interaction.editReply({ embeds: [base('TruckersMP • Events', lines.join('\n') || 'No event data returned.')] });
        }

        const p = await tmp.getPlayer(interaction.options.getString('id'));
        return interaction.editReply({ embeds: [base(`TruckersMP • ${p.name || 'Player'}`)
          .setThumbnail(p.avatar || p.smallAvatar || null)
          .addFields(
            { name: 'TruckersMP ID', value: String(p.id ?? 'Unknown'), inline: true },
            { name: 'SteamID64', value: String(p.steamID64 ?? p.steamID ?? 'Unknown'), inline: true },
            { name: 'Group', value: p.groupName || 'Player', inline: true },
            { name: 'Joined', value: p.joinDate || 'Unknown', inline: true },
            { name: 'Currently Banned', value: p.banned ? 'Yes' : 'No', inline: true },
            { name: 'VTC', value: p.vtc?.name || 'None / Private', inline: true }
          )] });
      }
    }
  ];
}

module.exports = { createCommands };

