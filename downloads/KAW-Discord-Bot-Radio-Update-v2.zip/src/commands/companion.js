// KAW Companion commands: onboarding (/companion), relay health (/relay) and live convoy data (/hub).
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require('discord.js');
const { base } = require('../ui/embeds');
const { isStaff } = require('../utils/permissions');
const relay = require('../services/companionRelay');
const { radioView } = require('../ui/radioButtons');
const { availableRadio } = require('../services/companionRadio');

const ts = iso => (iso ? `<t:${Math.floor(Date.parse(iso) / 1000)}:R>` : 'recently');
const money = v => `$${Math.round(Number(v) || 0).toLocaleString('en-US')}`;
const clip = (s, n = 1024) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s));

function isDriver(interaction, config) {
  if (isStaff(interaction, config)) return true;
  const roles = interaction.member?.roles?.cache;
  if (!roles) return false;
  const names = config.companion.driverRoleNames.map(n => n.toLowerCase());
  return roles.some(r => config.companion.driverRoleIds.includes(r.id) || names.includes(r.name.toLowerCase()));
}

const FEATURES = [
  '**🗺️ Convoy Hub** — live map of every driver, who has what DLC, where the whole convoy can drive, and the host\'s mod pack with one-click Steam Workshop links.',
  '**🎙️ Voice Co-Driver** — ask "how far?", "what gear?", "when do I rest?", or command the convoy by voice. Four personalities including CB Trucker.',
  '**⚙️ Smart shifting** — best gear from your truck\'s real gear ratios, shift-quality score, downhill and lugging hints.',
  '**⛽ Fuel & rest planner** — can you make it before you need sleep or fuel, and will you be on time.',
  '**⚠️ Driver alerts** — low fuel, rest, damage, cargo, speeding, deadline, warning lights, convoy gap keeper.',
  '**📋 Dispatch, BOLs & Company** — multi-stop runs, printable bills of lading, virtual trucking company with bank and payroll.',
  '**🏆 Career, challenges & leaderboards** — XP, achievements, daily challenges, weekly and monthly standings.',
  '**📅 Convoy events** — plan, RSVP, reminders 30 and 5 minutes before, replays of every convoy.',
  '**📻 CB radio & convoy radio** — Companion CB, shared internet radio, Discord voice fallback.',
  '**📱 Multi-screen & phone** — HUD, navigation screen, convoy map, OBS overlay, push notifications.'
];

const VOICE = [
  '**Ask:** how far · ETA · what gear · speed limit · when do I rest · fuel · can I make it · am I on time · damage report · status · alerts',
  '**Convoy:** who\'s online · where is *driver* · how far behind the leader · next convoy',
  '**Commands:** regroup · fuel stop · rest stop · hold position · depart · emergency stop',
  '**Shifting:** economy mode · balanced mode · power mode',
  '**Other:** how much have I earned · eco score · quiet · talk to me · repeat · tell me a joke · trucking fact',
  '',
  'Turn it on in the Companion: **Drive → Co-Driver → Listen for voice commands**. Hands-free: enable the wake word and say *"co-driver, how far?"*.'
];

function createCompanionCommands({ config }) {
  const setupReply = async (interaction, { dm = false } = {}) => {
    if (!isDriver(interaction, config)) {
      return interaction.reply({ content: `You need the **${config.companion.driverRoleNames[0] || 'ATS Driver'}** role to get the Companion connection details. Ask staff, or pick your game role in the server.`, ephemeral: true });
    }
    if (!config.relayApiKey) return interaction.reply({ content: 'The relay API key is not configured in the bot yet (`relayApiKey` in config.json). Ask staff.', ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    const name = interaction.member?.displayName || interaction.user.username;
    let rel = null;
    try { rel = await relay.latestRelease(config); } catch {}
    const link = relay.connectLink(config, name, interaction.guild?.name);
    const embed = base("KAW'S ATS Companion • Your setup").setDescription([
      `**1. Download** ${rel ? `[${rel.exeName || 'the installer'} (v${rel.version})](${rel.exeUrl})` : `from ${`https://github.com/${config.companion.downloadsRepo}/releases/latest`}`} and install it (Windows, internal drive, normally C:).`,
      '**2. Start** American Truck Simulator, then open **KAW\'S ATS Companion** from the Start menu.',
      `**3. Connect** — on the same PC, open this link: [**Connect my Companion**](${link})`,
      '　Your Companion asks you to confirm, then joins the convoy relay. Nothing to type.',
      '　No luck? Use the attached **config.json**: replace the one in the Companion\'s `companion` folder and restart the Companion.',
      '',
      `**Convoy code:** \`${config.companion.sessionCode}\``,
      `**Relay:** ${config.relayUrl}${config.companion.backupRelayUrl ? ` (backup: ${config.companion.backupRelayUrl})` : ''}`,
      `**Relay key:** ||${config.relayApiKey}||`,
      '',
      '**Next:** `/cb pair` for the CB radio · `/hub who` to see who\'s driving · `/companion voice` for voice commands.',
      '🔒 Keep the key and link private — they are only shown to you.'
    ].join('\n'));
    const files = [new AttachmentBuilder(Buffer.from(relay.configJson(config, name)), { name: 'config.json' })];
    const row = new ActionRowBuilder().addComponents(
      ...(rel ? [new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel(`Download v${rel.version}`).setURL(rel.exeUrl)] : []),
      new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('Live convoy page').setURL(relay.publicLiveUrl(config))
    );
    if (dm) {
      try {
        await interaction.user.send({ embeds: [embed], files, components: [row] });
        return interaction.editReply({ content: '📬 Sent your Companion setup to your DMs.' });
      } catch {
        return interaction.editReply({ content: "I couldn't DM you (DMs closed?). Here it is instead:", embeds: [embed], files, components: [row] });
      }
    }
    return interaction.editReply({ embeds: [embed], files, components: [row] });
  };

  const needRoster = async interaction => {
    await interaction.deferReply();
    try { return await relay.roster(config); }
    catch (e) { await interaction.editReply({ content: `Couldn't reach the convoy relay: ${e.message}` }); return null; }
  };

  const commands = [
    {
      data: new SlashCommandBuilder().setName('companion').setDescription("KAW'S ATS Companion: setup, download and features.")
        .addSubcommand(s => s.setName('setup').setDescription('Get your private Companion setup: download, one-click connect and config.').addBooleanOption(o => o.setName('dm').setDescription('Send it to your DMs instead')))
        .addSubcommand(s => s.setName('config').setDescription('Get a ready-made config.json for your Companion (private).'))
        .addSubcommand(s => s.setName('download').setDescription('Latest Companion installer.'))
        .addSubcommand(s => s.setName('features').setDescription('Everything the Companion can do.'))
        .addSubcommand(s => s.setName('voice').setDescription('Voice Co-Driver commands you can say while driving.'))
        .addSubcommand(s => s.setName('panel').setDescription('Post a "Get connected" panel with buttons in this channel (staff).')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'setup') return setupReply(interaction, { dm: interaction.options.getBoolean('dm') || false });
        if (sub === 'config') {
          if (!isDriver(interaction, config)) return interaction.reply({ content: 'You need the ATS Driver role for the Companion config.', ephemeral: true });
          const name = interaction.member?.displayName || interaction.user.username;
          return interaction.reply({ content: 'Your personal **config.json** — put it in the Companion\'s `companion` folder (replace the old one) and restart the Companion. Keep it private: it contains the relay key.', files: [new AttachmentBuilder(Buffer.from(relay.configJson(config, name)), { name: 'config.json' })], ephemeral: true });
        }
        if (sub === 'download') {
          await interaction.deferReply();
          try {
            const r = await relay.latestRelease(config);
            return interaction.editReply({ embeds: [base(`KAW'S ATS Companion v${r.version}`).setURL(r.url).setDescription([`**[Download ${r.exeName || 'installer'}](${r.exeUrl})** · released ${ts(r.publishedAt)}`, r.shaUrl ? `[SHA-256 checksum](${r.shaUrl})` : '', '', clip(r.notes, 900), '', 'After installing, run `/companion setup` to connect it to the convoy.'].filter(Boolean).join('\n'))] });
          } catch (e) { return interaction.editReply({ content: `Couldn't read the latest release: ${e.message}. Downloads: https://github.com/${config.companion.downloadsRepo}/releases/latest` }); }
        }
        if (sub === 'features') return interaction.reply({ embeds: [base("KAW'S ATS Companion • Features", FEATURES.join('\n\n')).setFooter({ text: 'Get started with /companion setup' })] });
        if (sub === 'voice') return interaction.reply({ embeds: [base('Voice Co-Driver • What you can say', VOICE.join('\n'))] });
        if (sub === 'panel') {
          if (!isStaff(interaction, config)) return interaction.reply({ content: 'Staff only.', ephemeral: true });
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('companion:setup').setStyle(ButtonStyle.Primary).setLabel('Get my Companion setup').setEmoji('🚚'),
            new ButtonBuilder().setCustomId('companion:features').setStyle(ButtonStyle.Secondary).setLabel('What can it do?'),
            new ButtonBuilder().setStyle(ButtonStyle.Link).setLabel('Live convoy page').setURL(relay.publicLiveUrl(config))
          );
          await interaction.channel.send({ embeds: [base("KAW'S ATS Companion • Get connected").setDescription([
            'The Companion links your American Truck Simulator to the convoy: live map, DLC & mod checks, voice co-driver, CB radio, dispatch and more.',
            '',
            'Press **Get my Companion setup** — you get the download, a one-click connect link and your personal config. Only you can see it.',
            `Requires the **${config.companion.driverRoleNames[0] || 'ATS Driver'}** role.`
          ].join('\n'))], components: [row] });
          return interaction.reply({ content: 'Panel posted.', ephemeral: true });
        }
      }
    },

    {
      data: new SlashCommandBuilder().setName('relay').setDescription('Convoy relay and CB radio status.')
        .addSubcommand(s => s.setName('status').setDescription('Health of the main and backup convoy relay.')),
      async execute({ interaction }) {
        await interaction.deferReply();
        const [main, backup] = await Promise.all([relay.health(config.relayUrl), config.companion.backupRelayUrl ? relay.health(config.companion.backupRelayUrl) : null]);
        const line = h => (h.up ? `🟢 **Online** · v${h.version} · ${h.latency} ms · up ${Math.round((h.uptime || 0) / 60)} min · ${h.sessions} session(s)` : h.suspended ? '🔴 **Suspended** by the host' : `🔴 **Down** · ${h.error || `HTTP ${h.status}`}`);
        const embed = base('KAW Convoy Relay • Status').addFields(
          { name: `Main — ${main.url.replace(/^https?:\/\//, '')}`, value: line(main) },
          ...(backup ? [{ name: `Backup — ${backup.url.replace(/^https?:\/\//, '')}`, value: line(backup) }] : []),
          { name: 'CB radio', value: `${main.up ? main.url : backup?.up ? backup.url : main.url}/radio`, inline: true },
          { name: 'Live convoy page', value: relay.publicLiveUrl(config), inline: true }
        );
        if (!main.up && !backup?.up) embed.setDescription(`Both relays are down — use Discord voice for now${config.companion.discordVoiceUrl ? `: ${config.companion.discordVoiceUrl}` : '.'}`);
        else if (!main.up) embed.setDescription('The main relay is down — Companions switch to the backup automatically.');
        return interaction.editReply({ embeds: [embed] });
      }
    },

    {
      data: new SlashCommandBuilder().setName('hub').setDescription('Live convoy info shared by drivers\' Companions.')
        .addSubcommand(s => s.setName('who').setDescription("Who's driving right now and where."))
        .addSubcommand(s => s.setName('where').setDescription('Where is a driver?').addStringOption(o => o.setName('driver').setDescription('Driver name').setRequired(true)))
        .addSubcommand(s => s.setName('dlc').setDescription('Who has what DLC, and where can everyone drive together?'))
        .addSubcommand(s => s.setName('mods').setDescription('Convoy mod packs and where to get each mod.'))
        .addSubcommand(s => s.setName('events').setDescription('Upcoming convoys and who is going.'))
        .addSubcommand(s => s.setName('standings').setDescription('Convoy leaderboard.').addStringOption(o => o.setName('period').setDescription('Period').addChoices({ name: 'This week', value: 'week' }, { name: 'Last week', value: 'lastWeek' }, { name: 'This season (month)', value: 'season' }, { name: 'All time', value: 'allTime' })))
        .addSubcommand(s => s.setName('radio').setDescription('What the convoy radio is playing.'))
        .addSubcommand(s => s.setName('page').setDescription('Link to the public live convoy page.')),
      async execute({ interaction }) {
        const sub = interaction.options.getSubcommand();
        if (sub === 'page') return interaction.reply({ content: `🌐 Live convoy page: ${relay.publicLiveUrl(config)}\nOnly drivers who turned on “Show me on the public live page” in their Companion appear there.` });
        if (sub === 'radio') {
          await interaction.deferReply();
          const view = radioView(await availableRadio(config));
          return interaction.editReply({ embeds: [base('Companion radio', view.description)], components: view.components, allowedMentions: { parse: [] } });
        }
        const r = await needRoster(interaction);
        if (!r) return;
        const online = r.drivers.filter(d => d.t.connected !== false);
        if (sub === 'who') {
          const lines = online.map(d => {
            const loc = d.t.location?.near ? `📍 near ${d.t.location.near}${d.t.location.nearState ? ', ' + d.t.location.nearState : ''}` : '📍 on the road';
            const job = d.t.job?.active ? `🚚 ${d.t.job.cargo || 'cargo'} → ${d.t.job.destinationCity || '?'}` : 'no job';
            return `**${d.driverName}** — ${Math.round(d.t.truck?.speedMph || 0)} mph · ${loc} · ${job}`;
          });
          return interaction.editReply({ embeds: [base(`Convoy Hub • ${online.length} driving now`, lines.join('\n') || 'Nobody is on the relay right now.').setFooter({ text: `Relay: ${r.relay.replace(/^https?:\/\//, '')}` })] });
        }
        if (sub === 'where') {
          const q = interaction.options.getString('driver').toLowerCase();
          const d = r.drivers.find(x => x.driverName.toLowerCase().includes(q));
          if (!d) return interaction.editReply({ content: `No driver matching “${interaction.options.getString('driver')}” is on the relay right now.` });
          const t = d.t;
          return interaction.editReply({ embeds: [base(`Where is ${d.driverName}?`).addFields(
            { name: 'Location', value: t.location?.near ? `Near ${t.location.near}${t.location.nearState ? ', ' + t.location.nearState : ''}${t.location.state ? ` (in ${t.location.state})` : ''}` : 'Not shared / map still calibrating', inline: true },
            { name: 'Speed', value: `${Math.round(t.truck?.speedMph || 0)} mph`, inline: true },
            { name: 'Truck', value: [t.truck?.make, t.truck?.model].filter(Boolean).join(' ') || '—', inline: true },
            { name: 'Job', value: t.job?.active ? `${t.job.cargo || 'Cargo'} · ${t.job.originCity || '?'} → ${t.job.destinationCity || '?'}${t.navigation?.distanceMiles ? ` · ${Math.round(t.navigation.distanceMiles)} mi left` : ''}` : 'No active job' },
            { name: 'Seen', value: ts(d.updatedAt), inline: true }
          )] });
        }
        if (sub === 'dlc') {
          const c = relay.dlcCoverage(online);
          if (!c.known.length) return interaction.editReply({ content: 'No online drivers are sharing their DLC yet (they need Companion v1.6+ with “Share my DLC & mods” on).' });
          const gaps = c.rows.filter(x => !x.base && x.missing.length && x.have.length).map(x => `**${x.state}** — missing: ${x.missing.join(', ')}`);
          const nobody = c.rows.filter(x => !x.have.length).map(x => x.state);
          return interaction.editReply({ embeds: [base(`Convoy DLC • ${c.known.length} driver(s) sharing`).addFields(
            { name: '✅ Everyone can drive', value: clip(c.everyone.join(', ') || 'Only the base map') },
            { name: '🟡 Some drivers are missing', value: clip(gaps.join('\n') || 'None — nice!') },
            ...(nobody.length ? [{ name: '⬜ Nobody owns', value: clip(nobody.join(', ')) }] : []),
            ...(c.unknown.length ? [{ name: 'Not sharing DLC', value: clip(c.unknown.join(', ')) }] : [])
          ).setFooter({ text: 'Open the Companion → Convoy Hub for the map and Steam links' })] });
        }
        if (sub === 'mods') {
          const packs = relay.modPacks(r.drivers);
          if (!packs.length) return interaction.editReply({ content: 'No convoy mod packs are shared right now. The host creates one in the Companion under **Convoy Pre-Flight**.' });
          const embeds = packs.slice(0, 4).map(p => base(`Mod pack • ${p.name}`).setDescription(clip([
            `Shared by **${p.from}**${p.gameVersion ? ` · game ${p.gameVersion}` : ''}`,
            p.requiredDlcTokens?.length ? `**Required DLC:** ${p.requiredDlcTokens.map(x => x.replace(/^dlc_/, '').replace(/_/g, ' ')).join(', ')}` : '',
            '',
            ...(p.mods || []).map((m, i) => `${i + 1}. ${m.required === false ? '(optional) ' : ''}**${m.name || 'Mod'}**${m.workshopId ? ` — [Workshop](https://steamcommunity.com/sharedfiles/filedetails/?id=${m.workshopId})` : ''}${m.url ? ` — [Download](${m.url})` : ''}`),
            '',
            p.notes ? `📝 ${p.notes}` : '',
            'Subscribe on the Workshop, then enable the mods in ATS **Mod Manager** in this order. Your Companion shows what you\'re missing.'
          ].filter(x => x !== '').join('\n'), 4000)));
          return interaction.editReply({ embeds });
        }
        if (sub === 'events') {
          const ev = relay.events(r.drivers);
          if (!ev.length) return interaction.editReply({ content: 'No convoys planned. Plan one in the Companion under **Convoy Sessions** — everyone gets reminders.' });
          return interaction.editReply({ embeds: [base('Upcoming convoys', ev.slice(0, 8).map(e => {
            const going = e.rsvps.filter(x => x.status === 'going').map(x => x.driverName);
            const when = e.status === 'active' ? '🟢 **rolling now**' : e.departureTime ? `<t:${Math.floor(Date.parse(e.departureTime) / 1000)}:F> (<t:${Math.floor(Date.parse(e.departureTime) / 1000)}:R>)` : 'time TBA';
            return `**${e.name}** — host ${e.host}\n${when}\n📍 ${e.meetPoint || 'TBA'}${e.destination ? ` → 🏁 ${e.destination}` : ''}\n✅ ${going.length} going${going.length ? `: ${going.join(', ')}` : ''}`;
          }).join('\n\n')).setFooter({ text: 'RSVP in the Companion → Convoy Sessions' })] });
        }
        if (sub === 'standings') {
          const period = interaction.options.getString('period') || 'week';
          const rows = r.drivers.map(d => ({ name: d.driverName, s: d.t.driverStats?.[period] })).filter(x => x.s);
          if (!rows.length) return interaction.editReply({ content: 'No stats shared yet — drivers need Companion v1.6+.' });
          const top = (key, fmt, asc = false) => rows.filter(x => x.s[key] != null && (key !== 'eco' || x.s.deliveries > 0)).sort((a, b) => (asc ? a.s[key] - b.s[key] : b.s[key] - a.s[key])).slice(0, 5).map((x, i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${x.name} — ${fmt(x.s[key])}`).join('\n') || '—';
          const label = { week: 'This week', lastWeek: 'Last week', season: 'This season', allTime: 'All time' }[period];
          return interaction.editReply({ embeds: [base(`Convoy standings • ${label}`).addFields(
            { name: 'Most miles', value: top('miles', v => `${Math.round(v).toLocaleString('en-US')} mi`), inline: true },
            { name: 'Top earner', value: top('income', money), inline: true },
            { name: 'Most deliveries', value: top('deliveries', v => String(v)), inline: true },
            { name: 'Cleanest loads', value: top('clean', v => `${v} clean`), inline: true },
            { name: 'Best eco', value: top('eco', v => `${v}/100`), inline: true },
            { name: 'Least speeding', value: top('speedingPct', v => `${v}%`, true), inline: true }
          )] });
        }

      }
    }
  ];

  // Buttons from the /companion panel.
  async function handleButton(interaction) {
    if (interaction.customId === 'companion:setup') { await setupReply(interaction); return true; }
    if (interaction.customId === 'companion:features') { await interaction.reply({ embeds: [base("KAW'S ATS Companion • Features", FEATURES.join('\n\n'))], ephemeral: true }); return true; }
    return false;
  }

  return { commands, handleButton };
}

module.exports = { createCompanionCommands };
