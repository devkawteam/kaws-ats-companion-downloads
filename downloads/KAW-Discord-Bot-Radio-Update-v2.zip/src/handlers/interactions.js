const { handleRadioButton } = require('./radio');
const { base, profileEmbed } = require('../ui/embeds');
const { convoyButtons } = require('../ui/components');
const { formatNumber } = require('../utils/discord');
const tmp = require('../services/truckersmp');
const { generateDispatch } = require('../services/dispatch');
const { resolveGameRoles } = require('../services/discordServerSetup');
const { canCreateConvoy } = require('../utils/permissions');
const cap = (v, n) => { const s = String(v || '').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

function parseRoute(route) {
  const parts = String(route).split(/→|->| to /i).map((s) => s.trim()).filter(Boolean);
  return {
    origin: parts[0] || 'Unknown',
    destination: parts[1] || 'Unknown'
  };
}

function parseTripDetails(text) {
  const lower = String(text || '').toLowerCase();
  const num = (rx) => {
    const m = lower.match(rx);
    return m ? Number(m[1]) : 0;
  };
  let cargoClass = 'standard';
  if (lower.includes('oversize')) cargoClass = 'oversize';
  else if (lower.includes('heavy')) cargoClass = 'heavy';
  else if (lower.includes('hazmat')) cargoClass = 'hazmat';

  return {
    cargoDamage: num(/cargo(?: damage)?\s*[:=]?\s*(\d+(?:\.\d+)?)/),
    truckDamage: num(/truck(?: damage)?\s*[:=]?\s*(\d+(?:\.\d+)?)/),
    trailerDamage: num(/trailer(?: damage)?\s*[:=]?\s*(\d+(?:\.\d+)?)/),
    fuelGallons: num(/fuel(?: gallons?| gal)?\s*[:=]?\s*(\d+(?:\.\d+)?)/),
    cargoClass
  };
}

async function handleInteraction({ interaction, commands, client, config, store, cbVoiceBridge, discordRelayBridge }) {
  if (interaction.isChatInputCommand()) {
    const command = commands.find((c) => c.data.name === interaction.commandName);
    if (!command) return;
    return command.execute({ interaction, client, config, store, cbVoiceBridge, discordRelayBridge });
  }

  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'profile:setup') {
      const profile = await store.saveProfile(interaction.user.id, {
        driverName: interaction.fields.getTextInputValue('driverName').trim(),
        preferredTruck: interaction.fields.getTextInputValue('preferredTruck').trim(),
        homeGarage: interaction.fields.getTextInputValue('homeGarage').trim(),
        truckersMpId: interaction.fields.getTextInputValue('truckersMpId').trim()
      });
      return interaction.reply({
        content: 'Driver profile saved.',
        embeds: [profileEmbed(interaction.user, profile, store.getUserStats(interaction.user.id))],
        ephemeral: true
      });
    }

    if (interaction.customId === 'trip:log') {
      const route = parseRoute(interaction.fields.getTextInputValue('route'));
      const miles = Number(interaction.fields.getTextInputValue('miles').replace(/[^0-9.]/g, ''));
      const incomeRaw = interaction.fields.getTextInputValue('income') || '0';
      const income = Number(incomeRaw.replace(/[^0-9.]/g, '')) || 0;
      const details = parseTripDetails(interaction.fields.getTextInputValue('details'));

      if (!Number.isFinite(miles) || miles <= 0) {
        return interaction.reply({ content: 'Miles must be a positive number.', ephemeral: true });
      }

      const { item, unlocked } = await store.addTrip({
        userId: interaction.user.id,
        guildId: interaction.guildId,
        ...route,
        cargo: interaction.fields.getTextInputValue('cargo').trim(),
        miles,
        income,
        ...details
      });

      const embed = base(`TRIP COMPLETE • ${item.id}`).addFields(
        { name: 'Route', value: `${item.origin} → ${item.destination}`, inline: false },
        { name: 'Cargo', value: item.cargo, inline: true },
        { name: 'Distance', value: `${formatNumber(item.miles)} mi`, inline: true },
        { name: 'Income', value: `$${formatNumber(item.income)}`, inline: true },
        { name: 'Cargo Damage', value: `${item.cargoDamage}%`, inline: true },
        { name: 'Fuel', value: `${formatNumber(item.fuelGallons)} gal`, inline: true },
        { name: 'XP Earned', value: `+${formatNumber(item.xpEarned)}`, inline: true }
      );

      if (unlocked.length) {
        const defs = store.getAllAchievementDefinitions();
        embed.addFields({
          name: 'Achievement Unlocked',
          value: unlocked.map((id) => `**${defs[id].name}** — ${defs[id].description}`).join('\n')
        });
      }

      return interaction.reply({ embeds: [embed] });
    }

    if (interaction.customId === 'convoy:create') {
      // Checked again on submit (v0.6.6).
      if (!canCreateConvoy(interaction, config)) return interaction.reply({ content: 'You need the **ATS** or **ATS Driver** role (or staff) to create a convoy.', ephemeral: true });
      const convoy = await store.createConvoy({
        title: cap(interaction.fields.getTextInputValue('title'), 100),
        route: cap(interaction.fields.getTextInputValue('route'), 1000),
        schedule: cap(interaction.fields.getTextInputValue('schedule'), 1000),
        details: cap(interaction.fields.getTextInputValue('details'), 3900),
        creatorId: interaction.user.id,
        guildId: interaction.guildId
      });

      return interaction.reply({
        content: 'Convoy created.',
        embeds: [base(`OFFICIAL CONVOY • ${convoy.title}`)
          .setDescription(convoy.details || 'ATS Playground official convoy.')
          .addFields(
            { name: 'Convoy ID', value: convoy.id, inline: true },
            { name: 'Route', value: convoy.route, inline: false },
            { name: 'Schedule', value: convoy.schedule, inline: false },
            { name: 'Drivers', value: '0', inline: true },
            { name: 'Ready', value: '0', inline: true },
            { name: 'Status', value: convoy.status, inline: true }
          )
          .setFooter({ text: 'Join the convoy, then use Ready/Fueling/AFK for live check-in.' })],
        components: convoyButtons(convoy.id)
      });
    }
  }

  if (interaction.isButton()) {
    if (await handleRadioButton({ interaction, config, cbVoiceBridge })) return;
    if (commands.companionButton && await commands.companionButton(interaction)) return;
    if (interaction.customId.startsWith('game-role:')) {
      const choice = interaction.customId.split(':')[1];
      const roles = resolveGameRoles(interaction.guild);
      if (!roles.ats || !roles.ets2) return interaction.reply({ content: 'The ATS/ETS2 roles are not configured yet. Ask an administrator to run `/server setup`.', ephemeral: true });
      const botHighest = interaction.guild.members.me.roles.highest;
      const blocked = [roles.ats, roles.ets2].filter(role => role.managed || botHighest.comparePositionTo(role) <= 0);
      if (blocked.length) return interaction.reply({ content: `Move the bot role above ${blocked.map(role => `**${role.name}**`).join(' and ')} in Server Settings → Roles, then try again.`, ephemeral: true });
      const member = interaction.member;
      if (choice === 'clear') {
        await member.roles.remove([roles.ats.id, roles.ets2.id], 'Driver changed ATS/ETS2 game selection');
        return interaction.reply({ content: 'Your ATS and ETS2 game roles were removed.', ephemeral: true });
      }
      const wanted = choice === 'both' ? [roles.ats, roles.ets2] : [roles[choice]];
      const unwanted = choice === 'both' ? [] : [choice === 'ats' ? roles.ets2 : roles.ats];
      if (unwanted.length) await member.roles.remove(unwanted.map(role => role.id), 'Driver changed ATS/ETS2 game selection');
      await member.roles.add(wanted.map(role => role.id), 'Driver selected ATS/ETS2 game access');
      return interaction.reply({ content: `Your game access is now: ${wanted.map(role => `**${role.name}**`).join(' and ')}.`, ephemeral: true });
    }

    if (interaction.customId === 'hub:profile') {
      return interaction.reply({
        embeds: [profileEmbed(interaction.user, store.getProfile(interaction.user.id), store.getUserStats(interaction.user.id))],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:stats') {
      const s = store.getUserStats(interaction.user.id);
      return interaction.reply({
        embeds: [base(`${interaction.user.username} • Career Statistics`).addFields(
          { name: 'Rank', value: s.rank.name, inline: true },
          { name: 'XP', value: formatNumber(s.xp), inline: true },
          { name: 'Miles', value: `${formatNumber(s.miles)} mi`, inline: true },
          { name: 'Trips', value: formatNumber(s.trips), inline: true },
          { name: 'Perfect Trips', value: formatNumber(s.perfectTrips), inline: true },
          { name: 'Convoys', value: formatNumber(s.convoys), inline: true }
        )],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:dispatch') {
      const item = await store.createDispatch({
        ...generateDispatch('random'),
        userId: interaction.user.id,
        guildId: interaction.guildId
      });
      return interaction.reply({
        embeds: [base(`DISPATCH ${item.id}`).addFields(
          { name: 'Origin', value: item.origin, inline: true },
          { name: 'Destination', value: item.destination, inline: true },
          { name: 'Cargo', value: item.cargo, inline: true },
          { name: 'Distance', value: `${formatNumber(item.miles)} mi`, inline: true },
          { name: 'Bonus XP', value: `+${formatNumber(item.bonusXp)}`, inline: true }
        )],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:convoys') {
      const convoys = store.getConvoys().slice(0, 8);
      const description = convoys.length ? convoys.map((c) => {
        const attendees = c.attendees || [];
        const ready = attendees.filter((a) => typeof a === 'object' && a.status === 'READY').length;
        return `**${c.id} • ${c.title}**\n${c.route} • ${c.schedule}\nDrivers: ${attendees.length} • Ready: ${ready}`;
      }).join('\n\n') : 'No convoys are scheduled yet.';
      return interaction.reply({ embeds: [base('ATS Playground • Upcoming Convoys', description)], ephemeral: true });
    }

    if (interaction.customId === 'hub:achievements') {
      const a = store.getAchievements(interaction.user.id);
      return interaction.reply({
        embeds: [base('ATS Playground • Achievements', a.length
          ? a.map((x) => `**${x.name}** — ${x.description}`).join('\n')
          : 'No achievements unlocked yet.')],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:challenges') {
      const c = store.getChallenges(interaction.user.id);
      return interaction.reply({
        embeds: [base('ATS Playground • Challenges', c.map((x) => `**${x.name}** — ${formatNumber(x.progress)}/${formatNumber(x.target)} • +${formatNumber(x.rewardXp)} XP`).join('\n'))],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:records') {
      const r = store.getPersonalRecords(interaction.user.id);
      return interaction.reply({
        content: r ? null : 'You need a tracked trip before records can be calculated.',
        embeds: r ? [base('ATS Playground • Personal Records').addFields(
          { name: 'Longest Trip', value: `${formatNumber(r.longest.miles)} mi`, inline: true },
          { name: 'Highest Paying', value: `$${formatNumber(r.richest.income)}`, inline: true },
          { name: 'Best MPG', value: r.bestFuel ? r.bestFuel.mpg.toFixed(2) : 'N/A', inline: true }
        )] : [],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:telemetry') {
      const link = store.getTelemetryLink(interaction.user.id);
      return interaction.reply({
        embeds: [base('ATS Playground • Telemetry')
          .setDescription('The live ATS Companion is the next major engineering phase.')
          .addFields(
            { name: 'Pairing Prepared', value: link?.active ? 'Yes' : 'No — use /telemetry link', inline: true },
            { name: 'Live Feed', value: 'Not connected yet', inline: true }
          )],
        ephemeral: true
      });
    }

    if (interaction.customId === 'hub:tmp') {
      await interaction.deferReply({ ephemeral: true });
      const [servers, version] = await Promise.all([tmp.getServers(), tmp.getVersion()]);
      return interaction.editReply({
        embeds: [base('TruckersMP • Live Network').addFields(
          { name: 'Servers Online', value: `${servers.filter((s) => s.online).length}/${servers.length}`, inline: true },
          { name: 'Players Online', value: formatNumber(servers.reduce((sum, s) => sum + Number(s.players || 0), 0)), inline: true },
          { name: 'ATS Supported', value: version.supported_ats_game_version || 'Unknown', inline: true }
        )]
      });
    }

    if (interaction.customId === 'hub:system') {
      await interaction.deferReply({ ephemeral: true });
      let api = 'ONLINE'; let latency = null;
      try { const h = await tmp.health(); latency = h.latency; } catch { api = 'OFFLINE'; }
      return interaction.editReply({
        embeds: [base('ATS Playground • System Status').addFields(
          { name: 'Discord', value: 'ONLINE', inline: true },
          { name: 'Bot Ping', value: `${client.ws.ping} ms`, inline: true },
          { name: 'TruckersMP API', value: latency ? `${api} • ${latency} ms` : api, inline: true },
          { name: 'Persistent Storage', value: 'ONLINE', inline: true }
        )]
      });
    }

    if (interaction.customId === 'hub:roadmap') {
      return interaction.reply({
        embeds: [base('ATS Playground • Roadmap').setDescription([
          '**Next major systems:**',
          '• ATS Companion desktop application',
          '• Live SCS telemetry ingestion',
          '• Automatic trip start/end detection',
          '• Live truck/fuel/damage/job status',
          '• Driver safety score & MPG analytics',
          '• Convoy live driver state',
          '• Web Operations Center',
          '• Live ATS map',
          '• Route intelligence',
          '• Mod/version compatibility center',
          '• ETS2 provider'
        ].join('\n'))],
        ephemeral: true
      });
    }

    if (interaction.customId.startsWith('convoy:rsvp:')) {
      const id = interaction.customId.split(':')[2];
      const convoy = await store.toggleConvoyAttendance(id, interaction.user.id);
      if (!convoy) return interaction.reply({ content: 'That convoy no longer exists.', ephemeral: true });
      const attendee = (convoy.attendees || []).find((a) => (typeof a === 'string' ? a : a.userId) === interaction.user.id);
      const joined = Boolean(attendee);
      const ready = (convoy.attendees || []).filter((a) => typeof a === 'object' && a.status === 'READY').length;
      await interaction.update({
        embeds: [base(`OFFICIAL CONVOY • ${convoy.title}`)
          .setDescription(convoy.details || 'ATS Playground official convoy.')
          .addFields(
            { name: 'Convoy ID', value: convoy.id, inline: true },
            { name: 'Route', value: convoy.route, inline: false },
            { name: 'Schedule', value: convoy.schedule, inline: false },
            { name: 'Drivers', value: String((convoy.attendees || []).length), inline: true },
            { name: 'Ready', value: String(ready), inline: true },
            { name: 'Status', value: convoy.status, inline: true }
          )],
        components: convoyButtons(convoy.id)
      });
      return interaction.followUp({ content: joined ? `You joined **${convoy.title}**.` : `You left **${convoy.title}**.`, ephemeral: true });
    }

    if (interaction.customId.startsWith('convoy:checkin:')) {
      const [, , id, status] = interaction.customId.split(':');
      const convoy = await store.setConvoyCheckin(id, interaction.user.id, status);
      if (!convoy) return interaction.reply({ content: 'That convoy no longer exists.', ephemeral: true });
      const ready = (convoy.attendees || []).filter((a) => typeof a === 'object' && a.status === 'READY').length;
      await interaction.update({
        embeds: [base(`OFFICIAL CONVOY • ${convoy.title}`)
          .setDescription(convoy.details || 'ATS Playground official convoy.')
          .addFields(
            { name: 'Convoy ID', value: convoy.id, inline: true },
            { name: 'Route', value: convoy.route, inline: false },
            { name: 'Schedule', value: convoy.schedule, inline: false },
            { name: 'Drivers', value: String((convoy.attendees || []).length), inline: true },
            { name: 'Ready', value: String(ready), inline: true },
            { name: 'Your Status', value: status, inline: true }
          )],
        components: convoyButtons(convoy.id)
      });
    }
  }
}

module.exports = { handleInteraction };

