'use strict';
const { PermissionFlagsBits } = require('discord.js');
const { isStaff } = require('../utils/permissions');
const relay = require('../services/companionRelay');
const { availableRadio } = require('../services/companionRadio');

async function handleRadioButton({ interaction, config, cbVoiceBridge }, getRoster = relay.roster, getAirwaves = relay.radioStations) {
  if (!interaction.customId.startsWith('convoy-radio:')) return false;
  const reply = content => interaction.reply({ content, ephemeral: true });
  if (!isStaff(interaction, config)) { await reply('You need ATS Playground staff permissions to control the Discord CB radio.'); return true; }
  const channel = interaction.member?.voice?.channel;
  if (!channel || channel.guild.id !== interaction.guildId) { await reply('Join the Discord voice channel where you want to hear the station first.'); return true; }
  const current = cbVoiceBridge.status();
  if (current.connected && (current.guildId !== interaction.guildId || current.voiceChannelId !== channel.id)) {
    await reply('Join the bot’s current voice channel, or use /cb join to move the bridge to your channel.'); return true;
  }
  await interaction.deferReply({ ephemeral: true });
  try {
    if (interaction.customId === 'convoy-radio:stop') {
      cbVoiceBridge.stopStation();
      await interaction.editReply({ content: 'Radio stopped in Discord. CB voice transmissions remain enabled.' });
    } else {
      const id = interaction.customId.slice('convoy-radio:play:'.length);
      const available = await availableRadio(config, getRoster, getAirwaves);
      const station = available.stations.find(s => s.id === id);
      if (!station) throw new Error('That station is no longer selected. Run /hub radio again.');
      const permissions = channel.permissionsFor(interaction.guild.members.me);
      if (![PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak].every(p => permissions?.has(p))) {
        throw new Error('The bot needs View Channel, Connect and Speak in your voice channel.');
      }
      if (!current.connected) await cbVoiceBridge.join(channel);
      await cbVoiceBridge.playStation(station);
      await interaction.editReply({ content: `Playing **${station.title}** in <#${channel.id}>. CB speech takes priority; the station resumes afterward.`, allowedMentions: { parse: [] } });
    }
  } catch (error) {
    await interaction.editReply({ content: `Radio could not be sent through CB: ${error.message}`, allowedMentions: { parse: [] } });
  }
  return true;
}
module.exports = { handleRadioButton };
